package com.disasterrelief.hub.service;

import com.disasterrelief.hub.database.entity.IncidentEntity;
import com.disasterrelief.hub.database.entity.enums.DisasterType;
import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.database.entity.enums.SeverityLevel;
import com.disasterrelief.hub.presentation.dto.request.IncidentCreateRequest;
import com.disasterrelief.hub.presentation.dto.response.IncidentResponse;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.IncidentRepository;
import com.disasterrelief.hub.service.impl.IncidentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IncidentServiceTest {

    @Mock
    private IncidentRepository incidentRepository;

    @Mock
    private AuditLogRepository auditLogRepository;

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private IncidentServiceImpl incidentService;

    private IncidentEntity sampleEntity;

    @BeforeEach
    void setUp() {
        sampleEntity = new IncidentEntity(
                "INC-TEST-001",
                "Flash Flood at Pier",
                DisasterType.FLOOD,
                SeverityLevel.CRITICAL,
                IncidentStatus.REPORTED,
                1500,
                "Pier 9",
                34.0,
                -118.0,
                "Flooding ongoing",
                "Chief Evans",
                "555-0199"
        );
        sampleEntity.setId(10L);
    }

    @Test
    void testReportIncident() {
        IncidentCreateRequest request = new IncidentCreateRequest();
        request.setTitle("Flash Flood at Pier");
        request.setDisasterType(DisasterType.FLOOD);
        request.setSeverity(SeverityLevel.CRITICAL);
        request.setLocationName("Pier 9");
        request.setAffectedPopulation(1500);

        when(incidentRepository.save(any(IncidentEntity.class))).thenReturn(sampleEntity);

        IncidentResponse response = incidentService.reportIncident(request);

        assertNotNull(response);
        assertEquals("INC-TEST-001", response.getIncidentCode());
        assertEquals("Flash Flood at Pier", response.getTitle());
        verify(incidentRepository, times(1)).save(any(IncidentEntity.class));
        verify(auditLogRepository, times(1)).save(any());
        verify(notificationService, times(1)).notifyIncidentCreated(any());
    }

    @Test
    void testUpdateIncidentStatus() {
        when(incidentRepository.findById(10L)).thenReturn(Optional.of(sampleEntity));
        when(incidentRepository.save(any(IncidentEntity.class))).thenReturn(sampleEntity);

        IncidentResponse response = incidentService.updateIncidentStatus(10L, IncidentStatus.CONTAINED);

        assertNotNull(response);
        assertEquals(IncidentStatus.CONTAINED, sampleEntity.getStatus());
        verify(incidentRepository, times(1)).save(sampleEntity);
    }
}
