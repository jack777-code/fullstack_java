package com.disasterrelief.hub.database.entity.enums;

public enum IncidentStatus {
    REPORTED,
    VERIFIED,
    IN_PROGRESS,
    CONTAINED,
    RESOLVED
}
