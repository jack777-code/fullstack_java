package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.DashboardMetricsResponse;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.service.AnalyticsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/analytics")
@CrossOrigin(origins = "*")
public class AnalyticsController {

    private final AnalyticsService analyticsService;
    private final AuditLogRepository auditLogRepository;

    public AnalyticsController(AnalyticsService analyticsService, AuditLogRepository auditLogRepository) {
        this.analyticsService = analyticsService;
        this.auditLogRepository = auditLogRepository;
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardMetricsResponse>> getMetrics() {
        return ResponseEntity.ok(ApiResponse.success(analyticsService.getRealtimeMetrics()));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<ApiResponse<List<AuditLogEntity>>> getAuditLogs() {
        return ResponseEntity.ok(ApiResponse.success(auditLogRepository.findTop50ByOrderByTimestampDesc()));
    }
}
