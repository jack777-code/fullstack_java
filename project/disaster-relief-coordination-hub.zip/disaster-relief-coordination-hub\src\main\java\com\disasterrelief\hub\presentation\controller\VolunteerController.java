package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import com.disasterrelief.hub.presentation.dto.request.VolunteerRegisterRequest;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.VolunteerResponse;
import com.disasterrelief.hub.service.VolunteerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/volunteers")
@CrossOrigin(origins = "*")
public class VolunteerController {

    private final VolunteerService volunteerService;

    public VolunteerController(VolunteerService volunteerService) {
        this.volunteerService = volunteerService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<VolunteerResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(volunteerService.getAllVolunteers()));
    }

    @GetMapping("/available")
    public ResponseEntity<ApiResponse<List<VolunteerResponse>>> getAvailable(
            @RequestParam(required = false) VolunteerSkill skill) {
        List<VolunteerResponse> list = (skill != null) 
                ? volunteerService.getAvailableBySkill(skill)
                : volunteerService.getAvailableVolunteers();
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<VolunteerResponse>> register(@Valid @RequestBody VolunteerRegisterRequest request) {
        VolunteerResponse response = volunteerService.registerVolunteer(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Volunteer registered successfully", response));
    }

    @PostMapping("/{id}/assign/{incidentId}")
    public ResponseEntity<ApiResponse<VolunteerResponse>> assignToIncident(
            @PathVariable Long id,
            @PathVariable Long incidentId) {
        VolunteerResponse response = volunteerService.assignToIncident(id, incidentId);
        return ResponseEntity.ok(ApiResponse.success("Volunteer assigned to incident #" + incidentId, response));
    }

    @PostMapping("/{id}/release")
    public ResponseEntity<ApiResponse<VolunteerResponse>> release(@PathVariable Long id) {
        VolunteerResponse response = volunteerService.releaseVolunteer(id);
        return ResponseEntity.ok(ApiResponse.success("Volunteer returned to standby pool", response));
    }
}
