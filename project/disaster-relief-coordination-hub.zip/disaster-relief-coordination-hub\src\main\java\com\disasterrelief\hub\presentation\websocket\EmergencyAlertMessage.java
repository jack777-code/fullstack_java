package com.disasterrelief.hub.presentation.websocket;

import java.time.LocalDateTime;

public class EmergencyAlertMessage {

    private String alertType; // e.g. "NEW_INCIDENT", "DISPATCH_SENT", "SHELTER_ALERT", "SYSTEM_BROADCAST"
    private String title;
    private String message;
    private String severity; // CRITICAL, HIGH, MODERATE, INFO
    private LocalDateTime timestamp;

    public EmergencyAlertMessage() {
        this.timestamp = LocalDateTime.now();
    }

    public EmergencyAlertMessage(String alertType, String title, String message, String severity) {
        this.alertType = alertType;
        this.title = title;
        this.message = message;
        this.severity = severity;
        this.timestamp = LocalDateTime.now();
    }

    public String getAlertType() {
        return alertType;
    }

    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
