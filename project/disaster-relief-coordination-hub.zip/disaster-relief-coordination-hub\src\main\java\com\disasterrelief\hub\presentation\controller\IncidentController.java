package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.presentation.dto.request.IncidentCreateRequest;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.IncidentResponse;
import com.disasterrelief.hub.service.IncidentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/incidents")
@CrossOrigin(origins = "*")
public class IncidentController {

    private final IncidentService incidentService;

    public IncidentController(IncidentService incidentService) {
        this.incidentService = incidentService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<IncidentResponse>> reportIncident(@Valid @RequestBody IncidentCreateRequest request) {
        IncidentResponse response = incidentService.reportIncident(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Incident reported and broadcasted successfully", response));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<IncidentResponse>>> getAllIncidents() {
        return ResponseEntity.ok(ApiResponse.success(incidentService.getAllIncidents()));
    }

    @GetMapping("/triage")
    public ResponseEntity<ApiResponse<List<IncidentResponse>>> getActiveTriage() {
        return ResponseEntity.ok(ApiResponse.success(incidentService.getActiveTriageIncidents()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<IncidentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(incidentService.getIncidentById(id)));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<IncidentResponse>> updateStatus(
            @PathVariable Long id,
            @RequestParam IncidentStatus status) {
        IncidentResponse updated = incidentService.updateIncidentStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Status updated to " + status, updated));
    }
}
