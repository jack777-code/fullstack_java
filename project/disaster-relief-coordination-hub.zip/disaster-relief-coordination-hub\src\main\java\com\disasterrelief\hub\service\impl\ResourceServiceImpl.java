package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.database.entity.ResourceInventoryEntity;
import com.disasterrelief.hub.database.entity.enums.ResourceCategory;
import com.disasterrelief.hub.presentation.dto.response.ResourceResponse;
import com.disasterrelief.hub.presentation.exception.ResourceNotFoundException;
import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.ResourceInventoryRepository;
import com.disasterrelief.hub.service.NotificationService;
import com.disasterrelief.hub.service.ResourceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ResourceServiceImpl implements ResourceService {

    private final ResourceInventoryRepository resourceRepository;
    private final AuditLogRepository auditLogRepository;
    private final NotificationService notificationService;

    public ResourceServiceImpl(ResourceInventoryRepository resourceRepository,
                               AuditLogRepository auditLogRepository,
                               NotificationService notificationService) {
        this.resourceRepository = resourceRepository;
        this.auditLogRepository = auditLogRepository;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ResourceResponse> getAllResources() {
        return resourceRepository.findAll().stream()
                .map(ResourceResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ResourceResponse> getResourcesByCategory(ResourceCategory category) {
        return resourceRepository.findByCategory(category).stream()
                .map(ResourceResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ResourceResponse> getLowStockAlerts() {
        return resourceRepository.findLowStockResources().stream()
                .map(ResourceResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public ResourceResponse restockResource(Long resourceId, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Restock quantity must be positive");
        }
        ResourceInventoryEntity resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResourceNotFoundException("Resource not found with ID: " + resourceId));

        resource.setTotalQuantity(resource.getTotalQuantity() + quantity);
        resource.setAvailableQuantity(resource.getAvailableQuantity() + quantity);
        ResourceInventoryEntity updated = resourceRepository.save(resource);

        auditLogRepository.save(new AuditLogEntity(
                "RESOURCE_RESTOCKED",
                "ResourceInventory",
                resource.getResourceCode(),
                "Replenished +" + quantity + " " + resource.getUnit() + " at " + resource.getWarehouseLocation(),
                "LOGISTICS_COORDINATOR"
        ));

        ResourceResponse response = ResourceResponse.fromEntity(updated);
        notificationService.notifyResourceUpdated(response);
        notificationService.notifyMetricsChanged();

        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public ResourceResponse getResourceById(Long resourceId) {
        ResourceInventoryEntity resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResourceNotFoundException("Resource not found with ID: " + resourceId));
        return ResourceResponse.fromEntity(resource);
    }
}
