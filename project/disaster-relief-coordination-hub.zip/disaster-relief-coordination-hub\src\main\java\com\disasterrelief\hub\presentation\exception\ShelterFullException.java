package com.disasterrelief.hub.presentation.exception;

public class ShelterFullException extends RuntimeException {
    public ShelterFullException(String message) {
        super(message);
    }
}
