package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.database.entity.enums.SeverityLevel;
import com.disasterrelief.hub.presentation.dto.response.DashboardMetricsResponse;
import com.disasterrelief.hub.repository.IncidentRepository;
import com.disasterrelief.hub.repository.ResourceInventoryRepository;
import com.disasterrelief.hub.repository.ShelterRepository;
import com.disasterrelief.hub.repository.VolunteerRepository;
import com.disasterrelief.hub.service.AnalyticsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class AnalyticsServiceImpl implements AnalyticsService {

    private final IncidentRepository incidentRepository;
    private final ShelterRepository shelterRepository;
    private final ResourceInventoryRepository resourceRepository;
    private final VolunteerRepository volunteerRepository;

    public AnalyticsServiceImpl(IncidentRepository incidentRepository,
                                ShelterRepository shelterRepository,
                                ResourceInventoryRepository resourceRepository,
                                VolunteerRepository volunteerRepository) {
        this.incidentRepository = incidentRepository;
        this.shelterRepository = shelterRepository;
        this.resourceRepository = resourceRepository;
        this.volunteerRepository = volunteerRepository;
    }

    @Override
    public DashboardMetricsResponse getRealtimeMetrics() {
        DashboardMetricsResponse metrics = new DashboardMetricsResponse();

        long totalIncidents = incidentRepository.count();
        long resolvedCount = incidentRepository.countByStatus(IncidentStatus.RESOLVED);
        long activeIncidents = Math.max(0, totalIncidents - resolvedCount);
        long criticalIncidents = incidentRepository.countBySeverity(SeverityLevel.CRITICAL);
        long totalAffected = incidentRepository.sumAffectedPopulationActive();

        long totalCapacity = shelterRepository.sumTotalCapacity();
        long currentOccupancy = shelterRepository.sumCurrentOccupancy();
        double occupancyRate = totalCapacity > 0 ? ((double) currentOccupancy / totalCapacity) * 100.0 : 0.0;

        long availableVolunteers = volunteerRepository.countByIsAvailableTrue();
        long totalSupplies = resourceRepository.sumTotalInventory();
        long lowStockCount = resourceRepository.findLowStockResources().size();

        // Calculate disaster readiness index (0 - 100 scale)
        // Factors: volunteer readiness, supply headroom, shelter availability
        double shelterHeadroom = totalCapacity > 0 ? Math.max(0, 100 - occupancyRate) : 50;
        double volunteerFactor = Math.min(100.0, availableVolunteers * 10.0);
        double supplyFactor = lowStockCount == 0 ? 100.0 : Math.max(20.0, 100.0 - (lowStockCount * 15.0));
        int readinessScore = (int) Math.round((shelterHeadroom * 0.3) + (volunteerFactor * 0.35) + (supplyFactor * 0.35));

        metrics.setTotalIncidents(totalIncidents);
        metrics.setActiveIncidents(activeIncidents);
        metrics.setCriticalIncidents(criticalIncidents);
        metrics.setTotalAffectedPopulation(totalAffected);
        metrics.setTotalShelterCapacity(totalCapacity);
        metrics.setCurrentShelterOccupancy(currentOccupancy);
        metrics.setOverallShelterOccupancyRate(Math.round(occupancyRate * 10.0) / 10.0);
        metrics.setAvailableVolunteers(availableVolunteers);
        metrics.setTotalSuppliesInStock(totalSupplies);
        metrics.setLowStockAlertsCount(lowStockCount);
        metrics.setDisasterReadinessIndex(Math.max(10, Math.min(100, readinessScore)));

        return metrics;
    }
}
