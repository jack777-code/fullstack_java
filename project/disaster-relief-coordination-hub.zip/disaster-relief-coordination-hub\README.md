# Disaster Relief Coordination Hub (DRCH)
> **Enterprise 4-Tier Full-Stack Java & Spring Boot Real-Time Incident Management System**

---

## 1. System Overview
The **Disaster Relief Coordination Hub** is a mission-critical, enterprise-grade emergency operations platform engineered for real-time disaster response, multi-agency resource allocation, emergency shelter administration, and volunteer mobilization. 

Built on an enterprise **4-Tier Layered Architecture**, the backend maintains strict separation of concerns, transactional integrity, and asynchronous STOMP/WebSocket event streaming to ensure responsive coordination during active emergencies.

---

## 2. Strict 4-Tier Architecture Specification

```
┌────────────────────────────────────────────────────────────────────────┐
│                   1. PRESENTATION LAYER (Web / REST / WS)              │
│  - REST Controllers (Incident, Resource, Shelter, Volunteer, Dispatch) │
│  - WebSocket STOMP Broker & Message Routing (/ws-relief, /topic)       │
│  - Enterprise Request/Response DTOs & Jakarta Bean Validation          │
│  - Global Exception Handling & RFC-7807 Error Responses                │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                   2. SERVICE LAYER (Business & Triage Engine)          │
│  - Core Services (Incident, Resource, Shelter, Volunteer, Dispatch)    │
│  - Dynamic Triage Prioritization & Readiness Index Calculation         │
│  - Real-Time Broadcast & Event Publishing via NotificationService      │
│  - Declarative Transaction Management (@Transactional)                 │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                   3. REPOSITORY LAYER (Data Access & Persistence)      │
│  - Spring Data JPA Repositories                                        │
│  - Custom Aggregations & Analytical JPQL Queries                       │
│  - Inventory Threshold & Shelter Capacity Query Filters                │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                   4. DATABASE LAYER (Schema, Entities & Storage)       │
│  - Relational JPA Entities (Incidents, Supplies, Shelters, Volunteers) │
│  - Enterprise Audit Trails (BaseAuditEntity, AuditLogEntity)           │
│  - In-Memory H2 Engine (Pre-seeded with active disaster data)          │
│  - External PostgreSQL / MySQL production capability                   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Layer-by-Layer Implementation Breakdown

### Tier 1: Presentation Layer
* **Location**: `com.disasterrelief.hub.presentation`
* **Components**:
  * **Controllers**:
    * `IncidentController`: Incident logging, active triage filtering, lifecycle status management.
    * `ResourceController`: Inventory queries, category filtering, stock replenishment.
    * `ShelterController`: Facility overview, occupancy alerts, evacuee check-ins.
    * `VolunteerController`: Personnel roster, status tracking, tactical field deployment.
    * `DispatchController`: Resource allocation and convoy dispatch dispatching.
    * `AnalyticsController`: Executive dashboard metrics and operational audit logs.
    * `WebSocketAlertController`: STOMP emergency broadcast relay.
  * **DTOs**: Enforces strong contract boundaries (`IncidentCreateRequest`, `ResourceAllocationRequest`, `ShelterCheckInRequest`, `VolunteerRegisterRequest`, `DashboardMetricsResponse`, etc.).
  * **Validation**: Jakarta `@NotNull`, `@NotBlank`, `@Min`, `@Size`.
  * **Exception Handling**: `GlobalExceptionHandler` with unified `ApiResponse<T>`.

### Tier 2: Service Layer
* **Location**: `com.disasterrelief.hub.service` & `com.disasterrelief.hub.service.impl`
* **Components**:
  * Interface-driven architecture (`IncidentService`, `ResourceService`, `ShelterService`, `VolunteerService`, `DispatchService`, `NotificationService`, `AnalyticsService`).
  * **Business Logic**:
    * Automated incident code generation (`INC-YYYY-XXXXXX`).
    * Inventory stock deduction and deficit prevention (`InsufficientSuppliesException`).
    * Shelter capacity enforcement (`ShelterFullException`).
    * Real-time Readiness Index calculation combining volunteer availability, shelter headroom, and logistical stock ratios.
    * Automated Audit Trail recording for all state-changing managerial operations.

### Tier 3: Repository Layer
* **Location**: `com.disasterrelief.hub.repository`
* **Components**:
  * `IncidentRepository`: Triage prioritization queries sorted by severity weight and timestamp.
  * `ResourceInventoryRepository`: Low-stock threshold detection queries.
  * `ShelterRepository`: Capacity and occupancy aggregations.
  * `VolunteerRepository`: Availability and skill-specific lookup methods.
  * `DispatchAllocationRepository`: Convoy tracking and historical log.
  * `AuditLogRepository`: Immutable timestamped action auditing.

### Tier 4: Database Layer
* **Location**: `com.disasterrelief.hub.database` & `src/main/resources`
* **Components**:
  * **Entities**:
    * `IncidentEntity`: Disaster details, severity, geolocations, affected population.
    * `ResourceInventoryEntity`: Warehouse logistics, stocks, threshold levels.
    * `ShelterEntity`: Evacuation camps, capacities, clinic status, food stocks.
    * `VolunteerEntity`: Personnel profiles, emergency skills, deployments.
    * `DispatchAllocationEntity`: Convoy allocations linking incidents and supplies.
    * `AuditLogEntity`: System-wide audit history.
  * **Database Configuration**:
    * H2 in-memory relational database (`jdbc:h2:mem:disaster_hub_db`) with H2 Console at `/h2-console`.
    * Standard DDL schema defined in `schema.sql`.
    * Realistic disaster seed data loaded via `data.sql`.

---

## 4. Full-Stack Responsive UI Design
Served directly from Spring Boot's static asset pipeline (`src/main/resources/static`):
* **Command Center Dashboard**: Executive KPI counter tiles, readiness gauge, and dynamic satellite radar grid simulation.
* **Real-Time WebSocket & Fallback Polling**: Automatic STOMP socket subscription (`/topic/alerts`, `/topic/incidents`, `/topic/resources`, `/topic/metrics-trigger`) with seamless HTTP polling fallback.
* **Emergency Ticker**: High-visibility scrolling alert bar for priority broadcasts.
* **Modals & Workflows**:
  * One-click Incident SOS Intake Form with instant client and server validation.
  * Supply Convoy Dispatcher with real-time stock deduction.
  * Shelter Evacuee Intake with automatic capacity threshold warnings.
  * Volunteer Roster & Field Deployment Manager.
* **Responsive Design**: Designed for ultra-wide command monitors, desktop laptops, field tablets, and mobile smartphones.
* **Dark / Light Mode**: Tactical dark command palette with high-contrast day mode toggle.

---

## 5. Technology Stack
* **Language**: Java 17+
* **Framework**: Spring Boot 3.2.5
* **Persistence**: Spring Data JPA / Hibernate ORM
* **Real-Time Communication**: Spring WebSocket + STOMP Messaging
* **Database**: H2 Database Engine (embedded / zero-install), compatible with PostgreSQL / MySQL
* **Monitoring & Operations**: Spring Boot Actuator (`/actuator/health`, `/actuator/metrics`)
* **Frontend**: Responsive HTML5, CSS3 Glassmorphism, Vanilla ES6+ JavaScript, FontAwesome Icons, SockJS & STOMP.js

---

## 6. Directory Layout
```
disaster-relief-coordination-hub/
├── pom.xml
├── README.md
└── src/
    ├── main/
    │   ├── java/com/disasterrelief/hub/
    │   │   ├── DisasterReliefHubApplication.java
    │   │   │
    │   │   ├── presentation/                 <-- 1. PRESENTATION LAYER
    │   │   │   ├── controller/               (REST & WS Controllers)
    │   │   │   ├── dto/                      (Request & Response Models)
    │   │   │   ├── websocket/                (STOMP Broker & Config)
    │   │   │   └── exception/                (Global Exception Handlers)
    │   │   │
    │   │   ├── service/                      <-- 2. SERVICE LAYER
    │   │   │   ├── *.java                    (Service Interfaces)
    │   │   │   └── impl/*.java               (Business Logic & Workflows)
    │   │   │
    │   │   ├── repository/                   <-- 3. REPOSITORY LAYER
    │   │   │   └── *Repository.java          (Spring Data JPA DAOs)
    │   │   │
    │   │   └── database/                     <-- 4. DATABASE LAYER
    │   │       ├── entity/                   (JPA Entities & Enums)
    │   │       └── config/                   (JPA Auditing Config)
    │   │
    │   └── resources/
    │       ├── application.yml               (Application Configuration)
    │       ├── schema.sql                    (Database DDL Blueprint)
    │       ├── data.sql                      (Seed Operational Data)
    │       └── static/                       (Responsive Web UI)
    │           ├── index.html
    │           ├── css/
    │           │   ├── dashboard.css
    │           │   └── responsive.css
    │           └── js/
    │               ├── app.js
    │               └── realtime.js
    └── test/
        └── java/com/disasterrelief/hub/
            ├── DisasterReliefHubApplicationTests.java
            └── service/IncidentServiceTest.java
```

---

## 7. How to Build & Run

### Prerequisites
* JDK 17 or higher
* Maven 3.8+ (or use IDE built-in build)

### Running via Terminal
```bash
cd disaster-relief-coordination-hub
mvn spring-boot:run
```

### Accessing the System
* **Operations Command Web Portal**: `http://localhost:8080`
* **H2 Database Web Console**: `http://localhost:8080/h2-console`
  * JDBC URL: `jdbc:h2:mem:disaster_hub_db`
  * Username: `sa`
  * Password: *(empty)*
* **Health & Actuator Metrics**: `http://localhost:8080/actuator/health`

---

## 8. REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/incidents` | Report a new emergency incident / SOS |
| `GET` | `/api/v1/incidents` | Fetch all recorded disaster incidents |
| `GET` | `/api/v1/incidents/triage` | Fetch prioritized active triage queue |
| `PATCH`| `/api/v1/incidents/{id}/status` | Update incident lifecycle status |
| `GET` | `/api/v1/resources` | List all emergency supply inventories |
| `POST` | `/api/v1/resources/{id}/restock` | Replenish warehouse supply stock |
| `GET` | `/api/v1/shelters` | List all shelters & current occupancy |
| `POST` | `/api/v1/shelters/check-in` | Record incoming evacuees |
| `GET` | `/api/v1/volunteers` | List volunteer roster and skill sets |
| `POST` | `/api/v1/volunteers/register` | Register new volunteer personnel |
| `POST` | `/api/v1/volunteers/{id}/assign/{incId}` | Deploy volunteer to incident |
| `POST` | `/api/v1/dispatches` | Authorize and record supply convoy dispatch |
| `GET` | `/api/v1/dispatches/recent` | View recent convoy dispatches |
| `GET` | `/api/v1/analytics/dashboard` | Get real-time executive KPI metrics |
| `GET` | `/api/v1/analytics/audit-logs` | Retrieve command audit trails |
