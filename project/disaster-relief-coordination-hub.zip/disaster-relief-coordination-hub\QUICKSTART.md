# Disaster Relief Coordination Hub - Quick Start Guide

This project is packaged to run seamlessly on **any computer** with minimal steps.

---

## 🚀 How to Run Locally

### Option 1: Double-Click Launcher (Windows)
1. Double-click the file **`run.bat`** in this folder.
2. The script checks for Java 17+, downloads the necessary dependencies using the Maven Wrapper, and starts the server.
3. Open your browser and navigate to:
   - **Command Center Web Portal**: `http://localhost:8080`
   - **H2 In-Memory Database Console**: `http://localhost:8080/h2-console`
     - JDBC URL: `jdbc:h2:mem:disaster_hub_db`
     - User Name: `sa`
     - Password: *(leave empty)*

---

### Option 2: Linux / macOS Launcher
1. Open a terminal in this project folder.
2. Make the script executable and run it:
   ```bash
   chmod +x run.sh mvnw
   ./run.sh
   ```
3. Open `http://localhost:8080` in your browser.

---

### Option 3: Using Docker (Zero Setup Required)
If you have Docker installed, you don't even need Java installed on your computer:
```bash
docker compose up --build
```
The server will build and run inside an isolated container at `http://localhost:8080`.

---

### Option 4: Run in Any Java IDE (IntelliJ IDEA / Eclipse / VS Code)
1. Open IntelliJ IDEA, Eclipse, or VS Code.
2. Select **Open** and pick this folder (`disaster-relief-coordination-hub`).
3. Locate the main application class:
   `src/main/java/com/disasterrelief/hub/DisasterReliefHubApplication.java`
4. Right-click and choose **Run 'DisasterReliefHubApplication'**.
5. Visit `http://localhost:8080`.

---

### Option 5: Instant Web UI Preview (No Java Needed)
If a user does not have Java installed and wants to inspect the responsive user interface right away:
* Double-click or open `src/main/resources/static/index.html` in Chrome, Edge, Firefox, or Safari!
