/**
 * Real-Time WebSocket and Event Broker Client
 * Disaster Relief Coordination Hub
 */

let stompClient = null;
let isConnected = false;

function initRealtimeConnection() {
    const statusPill = document.getElementById('wsConnectionStatus');
    
    try {
        if (typeof SockJS === 'undefined' || typeof Stomp === 'undefined') {
            console.warn('SockJS or Stomp library not detected. Starting autonomous fallback polling.');
            startFallbackPolling();
            return;
        }

        const socket = new SockJS('/ws-relief');
        stompClient = Stomp.over(socket);
        stompClient.debug = null; // suppress noisy logging

        stompClient.connect({}, function (frame) {
            isConnected = true;
            if (statusPill) {
                statusPill.innerText = "SYSTEM LIVE: WS CONNECTED";
                statusPill.parentElement.style.borderColor = "rgba(16, 185, 129, 0.4)";
            }
            console.log('Connected to Disaster Relief STOMP Broker');

            // Subscribe to High-Priority Emergency Broadcasts
            stompClient.subscribe('/topic/alerts', function (messageOutput) {
                const alert = JSON.parse(messageOutput.body);
                handleIncomingAlert(alert);
            });

            // Subscribe to Live Incidents
            stompClient.subscribe('/topic/incidents', function (messageOutput) {
                loadIncidents();
                loadDashboardMetrics();
            });

            // Subscribe to Resources
            stompClient.subscribe('/topic/resources', function (messageOutput) {
                loadResources();
                loadDashboardMetrics();
            });

            // Subscribe to Metrics Refresh Trigger
            stompClient.subscribe('/topic/metrics-trigger', function () {
                loadDashboardMetrics();
                loadRecentDispatches();
                loadShelters();
            });

        }, function (error) {
            console.warn('WebSocket connection failed. Falling back to HTTP polling:', error);
            isConnected = false;
            if (statusPill) {
                statusPill.innerText = "SYSTEM LIVE: POLLING MODE";
                statusPill.parentElement.style.borderColor = "rgba(245, 158, 11, 0.4)";
            }
            startFallbackPolling();
        });

    } catch (e) {
        console.warn('Real-time connection initialization skipped, using polling mode', e);
        startFallbackPolling();
    }
}

function handleIncomingAlert(alert) {
    // Update Emergency Ticker Bar
    const tickerBar = document.getElementById('alertTickerBar');
    const tickerText = document.getElementById('alertTickerText');
    if (tickerBar && tickerText) {
        tickerText.innerText = `[${alert.severity}] ${alert.title}: ${alert.message}`;
        tickerBar.style.display = 'flex';
    }

    // Display Toast
    showToast(alert.title, alert.message, alert.severity);
}

function startFallbackPolling() {
    // Active polling every 5 seconds to provide live updates seamlessly
    setInterval(() => {
        loadDashboardMetrics();
        loadRecentDispatches();
    }, 5000);
}
