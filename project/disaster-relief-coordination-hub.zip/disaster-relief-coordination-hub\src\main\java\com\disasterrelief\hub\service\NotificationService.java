package com.disasterrelief.hub.service;

import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;

public interface NotificationService {
    void broadcastAlert(EmergencyAlertMessage message);
    void notifyIncidentCreated(Object incident);
    void notifyResourceUpdated(Object resource);
    void notifyMetricsChanged();
}
