package com.disasterrelief.hub.service;

import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.presentation.dto.request.IncidentCreateRequest;
import com.disasterrelief.hub.presentation.dto.response.IncidentResponse;

import java.util.List;

public interface IncidentService {
    IncidentResponse reportIncident(IncidentCreateRequest request);
    List<IncidentResponse> getAllIncidents();
    List<IncidentResponse> getActiveTriageIncidents();
    IncidentResponse getIncidentById(Long id);
    IncidentResponse updateIncidentStatus(Long id, IncidentStatus newStatus);
}
