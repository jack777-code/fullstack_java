@echo off
title Disaster Relief Coordination Hub Launcher
color 0B
echo =========================================================================
echo       DISASTER RELIEF COORDINATION HUB - STARTUP LAUNCHER
echo =========================================================================
echo.

java -version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR] Java 17+ is not detected in your PATH.
    echo.
    echo To run the Spring Boot backend server, please install Java 17 or higher:
    echo https://adoptium.net/temurin/releases/
    echo.
    echo QUICK PREVIEW OPTION:
    echo You can immediately preview the responsive User Interface without Java:
    echo Simply open "src\main\resources\static\index.html" in any web browser!
    echo.
    pause
    exit /b 1
)

echo [OK] Java environment detected.
echo.
echo Launching Spring Boot server on port 8080...
echo Operations Web Portal: http://localhost:8080
echo In-Memory H2 Console:  http://localhost:8080/h2-console
echo.
echo (Press Ctrl + C in this terminal window anytime to stop the server)
echo =========================================================================
echo.

if exist "mvnw.cmd" (
    call mvnw.cmd spring-boot:run
) else (
    call mvn spring-boot:run
)

pause
