package com.disasterrelief.hub.service;

import com.disasterrelief.hub.presentation.dto.request.ResourceAllocationRequest;
import com.disasterrelief.hub.presentation.dto.response.DispatchResponse;

import java.util.List;

public interface DispatchService {
    DispatchResponse dispatchResource(ResourceAllocationRequest request);
    List<DispatchResponse> getDispatchesForIncident(Long incidentId);
    List<DispatchResponse> getRecentDispatches();
}
