package com.disasterrelief.hub.database.entity.enums;

public enum ResourceCategory {
    MEDICAL,
    FOOD_WATER,
    SHELTER_GEAR,
    RESCUE_EQUIPMENT,
    POWER_GENERATION,
    HAZMAT
}
