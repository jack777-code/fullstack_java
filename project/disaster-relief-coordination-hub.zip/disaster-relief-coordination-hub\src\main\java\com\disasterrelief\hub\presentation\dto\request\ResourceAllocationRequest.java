package com.disasterrelief.hub.presentation.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ResourceAllocationRequest {

    @NotNull(message = "Incident ID is required")
    private Long incidentId;

    @NotNull(message = "Resource ID is required")
    private Long resourceId;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Dispatched quantity must be at least 1")
    private Integer quantity;

    private String dispatchedBy;

    @Size(max = 500, message = "Notes cannot exceed 500 characters")
    private String notes;

    public ResourceAllocationRequest() {
    }

    public ResourceAllocationRequest(Long incidentId, Long resourceId, Integer quantity, String dispatchedBy, String notes) {
        this.incidentId = incidentId;
        this.resourceId = resourceId;
        this.quantity = quantity;
        this.dispatchedBy = dispatchedBy;
        this.notes = notes;
    }

    public Long getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(Long incidentId) {
        this.incidentId = incidentId;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getDispatchedBy() {
        return dispatchedBy;
    }

    public void setDispatchedBy(String dispatchedBy) {
        this.dispatchedBy = dispatchedBy;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
