package com.disasterrelief.hub.presentation.exception;

public class InsufficientSuppliesException extends RuntimeException {
    public InsufficientSuppliesException(String message) {
        super(message);
    }
}
