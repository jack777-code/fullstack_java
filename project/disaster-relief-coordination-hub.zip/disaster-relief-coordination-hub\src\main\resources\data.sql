-- Initial Seed Data for Disaster Relief Coordination Hub

-- 1. INCIDENTS
INSERT INTO incidents (id, incident_code, title, disaster_type, severity, status, affected_population, location_name, latitude, longitude, description, reported_by, contact_phone, created_at, updated_at) VALUES 
(1, 'INC-2026-FL001', 'Riverbank Breach & Flash Flooding', 'FLOOD', 'CRITICAL', 'IN_PROGRESS', 4200, 'Riverside Sector 4, Basin Lowlands', 34.0522, -118.2437, 'Primary embankment breach following torrential rainfall. Flood water rising rapidly. Trapped residents reported on rooftops.', 'Rescue Team Alpha', '+1-800-555-0199', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(2, 'INC-2026-EQ002', 'Sub-surface Tremor & Structural Distress', 'EARTHQUAKE', 'HIGH', 'REPORTED', 1850, 'Downtown Metro District, Central Plaza', 34.0601, -118.2512, 'Magnitude 5.8 tremor caused multiple wall fractures and minor gas leaks in commercial towers. Precautionary evacuation initiated.', 'Civil Defense Field Officer', '+1-800-555-0144', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(3, 'INC-2026-WF003', 'Canyon Ridge Brushfire Outbreak', 'WILDFIRE', 'HIGH', 'VERIFIED', 800, 'Pinecrest Valley & Ridgeway Foothills', 34.1120, -118.3005, 'Fast moving fire spreading along ridge line due to 35 knot winds. Mandatory evacuation warning active for hillside homes.', 'Forestry Recon Unit 3', '+1-800-555-0122', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(4, 'INC-2026-LS004', 'Highway Arterial Landslide Obstruction', 'LANDSLIDE', 'MODERATE', 'CONTAINED', 320, 'Mountain Pass Route 12, Mile Marker 45', 34.1500, -118.2800, 'Mud and boulder slide blocked major evacuation arterial route. Earth moving crews deployed.', 'Highway Patrol Dispatch', '+1-800-555-0188', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- 2. RESOURCE INVENTORY
INSERT INTO resource_inventory (id, resource_code, name, category, unit, total_quantity, allocated_quantity, available_quantity, warehouse_location, minimum_threshold, created_at, updated_at) VALUES
(1, 'RES-MED-01', 'Level-3 Trauma First Aid Kits', 'MEDICAL', 'Kits', 1500, 320, 1180, 'Central Logistics Depot - Bay 1', 250, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(2, 'RES-WTR-02', 'Purified Bottled Emergency Drinking Water', 'FOOD_WATER', 'Liters (Bottles)', 25000, 6500, 18500, 'Relief Depot North - Bay 4', 5000, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(3, 'RES-RAT-03', 'High-Calorie Ready-to-Eat Emergency Meals (MRE)', 'FOOD_WATER', 'Packs', 12000, 2800, 9200, 'Relief Depot North - Bay 2', 2000, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(4, 'RES-SHT-04', 'Rapid-Deploy Inflatable Shelter Tents (8-person)', 'SHELTER_GEAR', 'Tents', 450, 110, 340, 'Regional Supply Center West', 80, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(5, 'RES-BLK-05', 'Hypothermia Thermal Mylar Blankets', 'SHELTER_GEAR', 'Units', 8000, 1800, 6200, 'Regional Supply Center West', 1500, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(6, 'RES-BOT-06', 'High-Speed Zodiac Rescue Zodiac Boats', 'RESCUE_EQUIPMENT', 'Vessels', 35, 18, 17, 'Harbor Marine Station', 10, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(7, 'RES-PWR-07', 'Mobile Silent Diesel Generators (20 kVA)', 'POWER_GENERATION', 'Generators', 60, 25, 35, 'Central Logistics Depot - Yard 3', 15, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(8, 'RES-DRN-08', 'Thermal FLIR Reconnaissance Drones', 'RESCUE_EQUIPMENT', 'Drones', 20, 16, 4, 'Air Operations Hangar', 5, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- 3. SHELTER FACILITIES
INSERT INTO shelters (id, shelter_code, name, location_address, latitude, longitude, max_capacity, current_occupancy, status, contact_person, contact_phone, has_medical_unit, has_food_provisions, created_at, updated_at) VALUES
(1, 'SHL-WEST-01', 'Westside Memorial Civic Arena', '100 Olympic Blvd, West District', 34.0410, -118.2600, 1200, 890, 'OPEN', 'Major Elena Vance', '+1-555-321-4455', true, true, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(2, 'SHL-NORTH-02', 'Northridge Community Gymnasium', '540 Elm Avenue, Northside', 34.0720, -118.2300, 650, 615, 'NEAR_CAPACITY', 'Captain David Chen', '+1-555-321-7788', true, true, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(3, 'SHL-EAST-03', 'Highland Park Regional High School', '820 Arroyo Parkway, Highland', 34.0900, -118.1900, 850, 340, 'OPEN', 'Sarah Jenkins, RN', '+1-555-321-9922', true, true, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(4, 'SHL-HARBOR-04', 'St. Jude Youth Center Shelter', '312 Seaside Drive, Coastal Bay', 33.9800, -118.2800, 400, 400, 'FULL', 'Father Thomas Miller', '+1-555-321-1100', false, true, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- 4. VOLUNTEERS
INSERT INTO volunteers (id, volunteer_code, full_name, email, phone, primary_skill, is_available, current_assigned_incident_id, current_location, created_at, updated_at) VALUES
(1, 'VOL-MED-101', 'Dr. Marcus Holloway', 'marcus.h@medrelief.org', '+1-555-778-9001', 'PARAMEDIC', true, NULL, 'Standby - West Logistics Depot', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(2, 'VOL-SAR-102', 'Sarah O’Connor', 'sarah.sar@fieldops.org', '+1-555-778-9002', 'SEARCH_AND_RESCUE', false, 1, 'Field Unit - Riverside Sector 4', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(3, 'VOL-LOG-103', 'Ahmed Al-Mansoor', 'ahmed.logistics@hubrelief.net', '+1-555-778-9003', 'LOGISTICS', true, NULL, 'Standby - Supply Depot North', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(4, 'VOL-DRN-104', 'Chloe Dupont', 'chloe.uav@dronefirst.org', '+1-555-778-9004', 'DRONE_OPERATOR', false, 3, 'Field Unit - Pinecrest Ridge', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(5, 'VOL-ENG-105', 'Robert Kowalski', 'r.kowalski@engcorps.net', '+1-555-778-9005', 'HEAVY_MACHINERY', true, NULL, 'Standby - Motor Pool Yard', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(6, 'VOL-CNS-106', 'Grace Abernathy', 'grace.counseling@hope.org', '+1-555-778-9006', 'COUNSELING', true, NULL, 'Standby - Memorial Civic Arena', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- 5. INITIAL DISPATCH ALLOCATIONS
INSERT INTO dispatch_allocations (id, allocation_code, incident_id, resource_id, quantity_dispatched, dispatch_status, dispatched_at, dispatched_by, notes, created_at, updated_at) VALUES
(1, 'DSP-0914-A01', 1, 6, 8, 'EN_ROUTE', CURRENT_TIMESTAMP(), 'HQ Incident Commander', 'High-priority zodiac boats dispatched for rooftop evacuation.', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(2, 'DSP-0914-A02', 1, 2, 3000, 'DELIVERED', CURRENT_TIMESTAMP(), 'Logistics Officer Davis', 'Clean drinking water drop delivered to forward staging post.', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
(3, 'DSP-0914-A03', 3, 8, 4, 'EN_ROUTE', CURRENT_TIMESTAMP(), 'HQ Air Operations', 'Thermal recon drones deployed to trace wildland fire front.', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

-- 6. AUDIT LOGS
INSERT INTO audit_logs (id, action_type, entity_name, entity_identifier, details, performed_by, timestamp) VALUES
(1, 'SYSTEM_STARTUP', 'CoreApplication', 'DISASTER_RELIEF_HUB', 'Disaster Relief Coordination Hub engine booted into live status.', 'SYSTEM_INIT', CURRENT_TIMESTAMP()),
(2, 'INCIDENT_ESCALATION', 'Incident', 'INC-2026-FL001', 'Severity upgraded to CRITICAL due to flash flooding rate.', 'COMMANDER_ROSS', CURRENT_TIMESTAMP()),
(3, 'RESOURCE_DISPATCHED', 'DispatchAllocation', 'DSP-0914-A01', 'Dispatched 8 Zodiac boats to Riverside Sector 4.', 'HQ_DISPATCH_COMMAND', CURRENT_TIMESTAMP());
