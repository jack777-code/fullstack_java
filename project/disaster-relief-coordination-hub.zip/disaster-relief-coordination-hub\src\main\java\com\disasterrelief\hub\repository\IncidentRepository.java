package com.disasterrelief.hub.repository;

import com.disasterrelief.hub.database.entity.IncidentEntity;
import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.database.entity.enums.SeverityLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IncidentRepository extends JpaRepository<IncidentEntity, Long> {

    Optional<IncidentEntity> findByIncidentCode(String incidentCode);

    List<IncidentEntity> findByStatus(IncidentStatus status);

    List<IncidentEntity> findBySeverity(SeverityLevel severity);

    long countByStatus(IncidentStatus status);

    long countBySeverity(SeverityLevel severity);

    @Query("SELECT i FROM IncidentEntity i WHERE i.status != 'RESOLVED' ORDER BY i.severity DESC, i.createdAt DESC")
    List<IncidentEntity> findAllActiveTriageIncidents();

    @Query("SELECT COALESCE(SUM(i.affectedPopulation), 0) FROM IncidentEntity i WHERE i.status != 'RESOLVED'")
    long sumAffectedPopulationActive();
}
