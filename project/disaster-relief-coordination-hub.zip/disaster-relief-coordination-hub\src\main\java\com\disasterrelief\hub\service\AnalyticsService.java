package com.disasterrelief.hub.service;

import com.disasterrelief.hub.presentation.dto.response.DashboardMetricsResponse;

public interface AnalyticsService {
    DashboardMetricsResponse getRealtimeMetrics();
}
