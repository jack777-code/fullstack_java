package com.disasterrelief.hub.repository;

import com.disasterrelief.hub.database.entity.VolunteerEntity;
import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VolunteerRepository extends JpaRepository<VolunteerEntity, Long> {

    Optional<VolunteerEntity> findByVolunteerCode(String volunteerCode);

    List<VolunteerEntity> findByIsAvailableTrue();

    List<VolunteerEntity> findByPrimarySkillAndIsAvailableTrue(VolunteerSkill skill);

    List<VolunteerEntity> findByCurrentAssignedIncidentId(Long incidentId);

    long countByIsAvailableTrue();
}
