package com.disasterrelief.hub.presentation.dto.response;

import com.disasterrelief.hub.database.entity.ShelterEntity;
import com.disasterrelief.hub.database.entity.enums.ShelterStatus;

public class ShelterResponse {

    private Long id;
    private String shelterCode;
    private String name;
    private String locationAddress;
    private Double latitude;
    private Double longitude;
    private Integer maxCapacity;
    private Integer currentOccupancy;
    private Integer availableBeds;
    private Double occupancyPercentage;
    private ShelterStatus status;
    private String contactPerson;
    private String contactPhone;
    private Boolean hasMedicalUnit;
    private Boolean hasFoodProvisions;

    public ShelterResponse() {
    }

    public static ShelterResponse fromEntity(ShelterEntity entity) {
        if (entity == null) return null;
        ShelterResponse dto = new ShelterResponse();
        dto.setId(entity.getId());
        dto.setShelterCode(entity.getShelterCode());
        dto.setName(entity.getName());
        dto.setLocationAddress(entity.getLocationAddress());
        dto.setLatitude(entity.getLatitude());
        dto.setLongitude(entity.getLongitude());
        dto.setMaxCapacity(entity.getMaxCapacity());
        dto.setCurrentOccupancy(entity.getCurrentOccupancy());
        int available = Math.max(0, entity.getMaxCapacity() - entity.getCurrentOccupancy());
        dto.setAvailableBeds(available);
        double pct = entity.getMaxCapacity() > 0 
                ? ((double) entity.getCurrentOccupancy() / entity.getMaxCapacity()) * 100.0 
                : 0.0;
        dto.setOccupancyPercentage(Math.round(pct * 10.0) / 10.0);
        dto.setStatus(entity.getStatus());
        dto.setContactPerson(entity.getContactPerson());
        dto.setContactPhone(entity.getContactPhone());
        dto.setHasMedicalUnit(entity.getHasMedicalUnit());
        dto.setHasFoodProvisions(entity.getHasFoodProvisions());
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShelterCode() {
        return shelterCode;
    }

    public void setShelterCode(String shelterCode) {
        this.shelterCode = shelterCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocationAddress() {
        return locationAddress;
    }

    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Integer getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public Integer getCurrentOccupancy() {
        return currentOccupancy;
    }

    public void setCurrentOccupancy(Integer currentOccupancy) {
        this.currentOccupancy = currentOccupancy;
    }

    public Integer getAvailableBeds() {
        return availableBeds;
    }

    public void setAvailableBeds(Integer availableBeds) {
        this.availableBeds = availableBeds;
    }

    public Double getOccupancyPercentage() {
        return occupancyPercentage;
    }

    public void setOccupancyPercentage(Double occupancyPercentage) {
        this.occupancyPercentage = occupancyPercentage;
    }

    public ShelterStatus getStatus() {
        return status;
    }

    public void setStatus(ShelterStatus status) {
        this.status = status;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public Boolean getHasMedicalUnit() {
        return hasMedicalUnit;
    }

    public void setHasMedicalUnit(Boolean hasMedicalUnit) {
        this.hasMedicalUnit = hasMedicalUnit;
    }

    public Boolean getHasFoodProvisions() {
        return hasFoodProvisions;
    }

    public void setHasFoodProvisions(Boolean hasFoodProvisions) {
        this.hasFoodProvisions = hasFoodProvisions;
    }
}
