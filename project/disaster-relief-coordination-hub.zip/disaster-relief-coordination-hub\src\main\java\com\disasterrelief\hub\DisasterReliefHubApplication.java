package com.disasterrelief.hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisasterReliefHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(DisasterReliefHubApplication.class, args);
    }
}
