package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.database.entity.DispatchAllocationEntity;
import com.disasterrelief.hub.database.entity.IncidentEntity;
import com.disasterrelief.hub.database.entity.ResourceInventoryEntity;
import com.disasterrelief.hub.presentation.dto.request.ResourceAllocationRequest;
import com.disasterrelief.hub.presentation.dto.response.DispatchResponse;
import com.disasterrelief.hub.presentation.dto.response.ResourceResponse;
import com.disasterrelief.hub.presentation.exception.InsufficientSuppliesException;
import com.disasterrelief.hub.presentation.exception.ResourceNotFoundException;
import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.DispatchAllocationRepository;
import com.disasterrelief.hub.repository.IncidentRepository;
import com.disasterrelief.hub.repository.ResourceInventoryRepository;
import com.disasterrelief.hub.service.DispatchService;
import com.disasterrelief.hub.service.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class DispatchServiceImpl implements DispatchService {

    private final DispatchAllocationRepository dispatchRepository;
    private final IncidentRepository incidentRepository;
    private final ResourceInventoryRepository resourceRepository;
    private final AuditLogRepository auditLogRepository;
    private final NotificationService notificationService;

    public DispatchServiceImpl(DispatchAllocationRepository dispatchRepository,
                               IncidentRepository incidentRepository,
                               ResourceInventoryRepository resourceRepository,
                               AuditLogRepository auditLogRepository,
                               NotificationService notificationService) {
        this.dispatchRepository = dispatchRepository;
        this.incidentRepository = incidentRepository;
        this.resourceRepository = resourceRepository;
        this.auditLogRepository = auditLogRepository;
        this.notificationService = notificationService;
    }

    @Override
    public DispatchResponse dispatchResource(ResourceAllocationRequest request) {
        IncidentEntity incident = incidentRepository.findById(request.getIncidentId())
                .orElseThrow(() -> new ResourceNotFoundException("Incident not found with ID: " + request.getIncidentId()));

        ResourceInventoryEntity resource = resourceRepository.findById(request.getResourceId())
                .orElseThrow(() -> new ResourceNotFoundException("Resource not found with ID: " + request.getResourceId()));

        if (resource.getAvailableQuantity() < request.getQuantity()) {
            throw new InsufficientSuppliesException("Insufficient inventory for " + resource.getName()
                    + ". Requested: " + request.getQuantity() + " " + resource.getUnit()
                    + ", Available: " + resource.getAvailableQuantity() + " " + resource.getUnit());
        }

        // Deduct inventory
        resource.setAvailableQuantity(resource.getAvailableQuantity() - request.getQuantity());
        resource.setAllocatedQuantity(resource.getAllocatedQuantity() + request.getQuantity());
        resourceRepository.save(resource);

        String allocationCode = "DSP-" + UUID.randomUUID().toString().substring(0, 7).toUpperCase();

        DispatchAllocationEntity allocation = new DispatchAllocationEntity(
                allocationCode,
                incident,
                resource,
                request.getQuantity(),
                "EN_ROUTE",
                LocalDateTime.now(),
                request.getDispatchedBy() != null ? request.getDispatchedBy() : "LOGISTICS_HQ",
                request.getNotes()
        );

        DispatchAllocationEntity saved = dispatchRepository.save(allocation);

        auditLogRepository.save(new AuditLogEntity(
                "RESOURCE_DISPATCHED",
                "DispatchAllocation",
                saved.getAllocationCode(),
                "Dispatched " + request.getQuantity() + " " + resource.getUnit() + " of " + resource.getName()
                        + " to Incident [" + incident.getIncidentCode() + " - " + incident.getTitle() + "]",
                allocation.getDispatchedBy()
        ));

        // Real-time alerts
        notificationService.notifyResourceUpdated(ResourceResponse.fromEntity(resource));
        notificationService.broadcastAlert(new EmergencyAlertMessage(
                "DISPATCH_SENT",
                "Supply Convoy Dispatched!",
                request.getQuantity() + " " + resource.getUnit() + " of " + resource.getName() + " dispatched to " + incident.getLocationName(),
                "MODERATE"
        ));
        notificationService.notifyMetricsChanged();

        return DispatchResponse.fromEntity(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DispatchResponse> getDispatchesForIncident(Long incidentId) {
        return dispatchRepository.findByIncidentId(incidentId).stream()
                .map(DispatchResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<DispatchResponse> getRecentDispatches() {
        return dispatchRepository.findTop15ByOrderByCreatedAtDesc().stream()
                .map(DispatchResponse::fromEntity)
                .collect(Collectors.toList());
    }
}
