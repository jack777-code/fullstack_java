/**
 * Disaster Relief Coordination Hub - Main Operations Frontend Logic
 * Full-Stack Spring Boot Client
 */

let cachedIncidents = [];
let cachedResources = [];
let cachedShelters = [];
let cachedVolunteers = [];

document.addEventListener('DOMContentLoaded', () => {
    initNavigationTabs();
    initModals();
    initThemeToggle();
    initForms();

    // Initial Data Fetch
    loadDashboardMetrics();
    loadIncidents();
    loadResources();
    loadShelters();
    loadVolunteers();
    loadRecentDispatches();
    loadAuditLogs();

    // Connect Real-Time Broker
    initRealtimeConnection();
});

// NAVIGATION TABS
function initNavigationTabs() {
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const targetId = tab.getAttribute('data-tab');
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            const targetPane = document.getElementById(targetId);
            if (targetPane) {
                targetPane.classList.add('active');
            }

            // Lazy refresh specific tab content
            if (targetId === 'tab-audit') loadAuditLogs();
            if (targetId === 'tab-resources') loadResources();
            if (targetId === 'tab-shelters') loadShelters();
            if (targetId === 'tab-volunteers') loadVolunteers();
        });
    });
}

// THEME TOGGLER
function initThemeToggle() {
    const btn = document.getElementById('themeToggleBtn');
    if (!btn) return;
    btn.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const icon = btn.querySelector('i');
        if (document.body.classList.contains('light-theme')) {
            icon.className = 'fa-solid fa-sun';
        } else {
            icon.className = 'fa-solid fa-moon';
        }
    });
}

// MODAL CONTROLS
function initModals() {
    // Open SOS modal buttons
    const btnSos1 = document.getElementById('btnSosModalOpen');
    const btnSos2 = document.getElementById('btnSosModalOpen2');
    if (btnSos1) btnSos1.onclick = () => openModal('modalIncident');
    if (btnSos2) btnSos2.onclick = () => openModal('modalIncident');

    // Open Dispatch modal buttons
    const btnDisp1 = document.getElementById('btnOpenDispatchModal');
    const btnDisp2 = document.getElementById('btnOpenDispatchModal2');
    if (btnDisp1) btnDisp1.onclick = () => openDispatchModal();
    if (btnDisp2) btnDisp2.onclick = () => openDispatchModal();

    // Open Check-in modal
    const btnChk1 = document.getElementById('btnOpenCheckInModal');
    const btnChk2 = document.getElementById('btnOpenCheckInModal2');
    if (btnChk1) btnChk1.onclick = () => openCheckInModal();
    if (btnChk2) btnChk2.onclick = () => openCheckInModal();

    // Open Volunteer modal
    const btnVol = document.getElementById('btnOpenVolunteerModal');
    if (btnVol) btnVol.onclick = () => openModal('modalVolunteer');
}

function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('open');
}

function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('open');
}

// DASHBOARD METRICS
async function loadDashboardMetrics() {
    try {
        const res = await fetch('/api/v1/analytics/dashboard');
        const json = await res.json();
        if (json.success && json.data) {
            const m = json.data;
            document.getElementById('kpiCriticalIncidents').innerText = m.criticalIncidents;
            document.getElementById('kpiTotalIncidents').innerText = `${m.activeIncidents} Active Cases`;
            document.getElementById('kpiAffectedPop').innerText = Number(m.totalAffectedPopulation).toLocaleString();
            document.getElementById('kpiShelterOccupancy').innerText = Number(m.currentShelterOccupancy).toLocaleString();
            document.getElementById('kpiShelterCapacity').innerText = `${m.overallShelterOccupancyRate}% Occupancy Rate`;
            document.getElementById('kpiVolunteers').innerText = m.availableVolunteers;
            document.getElementById('kpiSupplies').innerText = Number(m.totalSuppliesInStock).toLocaleString();
            document.getElementById('kpiLowStock').innerText = `${m.lowStockAlertsCount} Low Stock Item(s)`;

            const bar = document.getElementById('readinessBar');
            const score = document.getElementById('readinessScore');
            if (bar && score) {
                bar.style.width = `${m.disasterReadinessIndex}%`;
                score.innerText = `${m.disasterReadinessIndex}%`;
            }
        }
    } catch (e) {
        console.error('Failed to load metrics:', e);
    }
}

// INCIDENTS
async function loadIncidents() {
    try {
        const res = await fetch('/api/v1/incidents');
        const json = await res.json();
        if (json.success && json.data) {
            cachedIncidents = json.data;
            renderIncidentsTable(cachedIncidents);
            renderTriageStream(cachedIncidents);
            const countBadge = document.getElementById('tabCountIncidents');
            if (countBadge) countBadge.innerText = cachedIncidents.length;
        }
    } catch (e) {
        console.error('Failed to load incidents:', e);
    }
}

function renderIncidentsTable(incidents) {
    const tbody = document.getElementById('allIncidentsBody');
    if (!tbody) return;

    if (incidents.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding: 2rem;">No incidents recorded.</td></tr>`;
        return;
    }

    tbody.innerHTML = incidents.map(inc => `
        <tr>
            <td><strong>${inc.incidentCode}</strong></td>
            <td><span class="badge badge-status">${inc.disasterType}</span></td>
            <td>
                <strong>${inc.title}</strong>
                <p style="font-size:0.75rem; color:var(--text-secondary); margin-top:2px;">${inc.description || 'No detailed description.'}</p>
            </td>
            <td><span class="badge badge-${inc.severity}">${inc.severity}</span></td>
            <td>
                <select class="form-input" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onchange="updateIncidentStatus(${inc.id}, this.value)">
                    <option value="REPORTED" ${inc.status === 'REPORTED' ? 'selected' : ''}>Reported</option>
                    <option value="VERIFIED" ${inc.status === 'VERIFIED' ? 'selected' : ''}>Verified</option>
                    <option value="IN_PROGRESS" ${inc.status === 'IN_PROGRESS' ? 'selected' : ''}>In Progress</option>
                    <option value="CONTAINED" ${inc.status === 'CONTAINED' ? 'selected' : ''}>Contained</option>
                    <option value="RESOLVED" ${inc.status === 'RESOLVED' ? 'selected' : ''}>Resolved</option>
                </select>
            </td>
            <td>${inc.locationName}</td>
            <td>${Number(inc.affectedPopulation).toLocaleString()}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="quickDispatchToIncident(${inc.id})">
                    <i class="fa-solid fa-truck"></i> Dispatch
                </button>
            </td>
        </tr>
    `).join('');
}

function renderTriageStream(incidents) {
    const stream = document.getElementById('overviewTriageList');
    if (!stream) return;

    const activeList = incidents.filter(i => i.status !== 'RESOLVED');
    if (activeList.length === 0) {
        stream.innerHTML = `<div style="text-align:center; padding:1.5rem; color:var(--text-muted);">All incidents contained and resolved.</div>`;
        return;
    }

    stream.innerHTML = activeList.map(inc => `
        <div class="triage-card sev-${inc.severity}">
            <div class="triage-top">
                <span class="badge badge-${inc.severity}">${inc.severity}</span>
                <span style="color:var(--text-muted); font-size:0.7rem;">${inc.incidentCode}</span>
            </div>
            <div class="triage-title">${inc.title}</div>
            <div class="triage-meta">
                <span><i class="fa-solid fa-location-dot"></i> ${inc.locationName}</span>
                <span><i class="fa-solid fa-users"></i> ${inc.affectedPopulation || 0}</span>
            </div>
        </div>
    `).join('');
}

async function updateIncidentStatus(id, newStatus) {
    try {
        const res = await fetch(`/api/v1/incidents/${id}/status?status=${newStatus}`, { method: 'PATCH' });
        const json = await res.json();
        if (json.success) {
            showToast('Status Updated', `Incident #${id} transitioned to ${newStatus}`, 'SUCCESS');
            loadIncidents();
            loadDashboardMetrics();
        }
    } catch (e) {
        showToast('Error', 'Failed to update status', 'CRITICAL');
    }
}

// LOGISTICS & RESOURCES
async function loadResources() {
    try {
        const res = await fetch('/api/v1/resources');
        const json = await res.json();
        if (json.success && json.data) {
            cachedResources = json.data;
            renderResourceCards(cachedResources);
        }
    } catch (e) {
        console.error('Failed to load resources:', e);
    }
}

function renderResourceCards(resources) {
    const grid = document.getElementById('resourceCardsGrid');
    if (!grid) return;

    grid.innerHTML = resources.map(r => {
        const pct = Math.round((r.availableQuantity / r.totalQuantity) * 100);
        let barColor = 'fill-green';
        if (pct < 25) barColor = 'fill-red';
        else if (pct < 50) barColor = 'fill-amber';

        return `
            <div class="resource-card">
                <div>
                    <div class="resource-card-header">
                        <span class="badge badge-status">${r.category}</span>
                        ${r.lowStock ? '<span class="badge badge-CRITICAL">LOW STOCK</span>' : ''}
                    </div>
                    <div class="resource-card-title">${r.name}</div>
                    <div style="font-size:0.75rem; color:var(--text-muted); margin:4px 0;">Warehouse: ${r.warehouseLocation}</div>
                    
                    <div class="progress-track">
                        <div class="progress-fill ${barColor}" style="width: ${pct}%;"></div>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:var(--text-secondary);">
                        <span>Available: <strong>${Number(r.availableQuantity).toLocaleString()} ${r.unit}</strong></span>
                        <span>Total: ${Number(r.totalQuantity).toLocaleString()}</span>
                    </div>
                </div>
                <div style="margin-top:1rem; display:flex; gap:0.5rem;">
                    <button class="btn btn-sm btn-outline" style="flex:1;" onclick="promptRestock(${r.id}, '${r.name}')">
                        <i class="fa-solid fa-plus"></i> Restock
                    </button>
                    <button class="btn btn-sm btn-primary" style="flex:1;" onclick="openDispatchForResource(${r.id})">
                        <i class="fa-solid fa-truck-ramp-box"></i> Dispatch
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

async function promptRestock(resourceId, name) {
    const qtyStr = prompt(`Enter restock quantity for "${name}":`, "100");
    if (!qtyStr) return;
    const qty = parseInt(qtyStr, 10);
    if (isNaN(qty) || qty <= 0) {
        alert("Please enter a valid positive number.");
        return;
    }

    try {
        const res = await fetch(`/api/v1/resources/${resourceId}/restock?quantity=${qty}`, { method: 'POST' });
        const json = await res.json();
        if (json.success) {
            showToast('Restocked', `Added ${qty} units to ${name}`, 'SUCCESS');
            loadResources();
            loadDashboardMetrics();
        } else {
            showToast('Error', json.message, 'CRITICAL');
        }
    } catch (e) {
        showToast('Error', 'Restock failed', 'CRITICAL');
    }
}

// SHELTERS
async function loadShelters() {
    try {
        const res = await fetch('/api/v1/shelters');
        const json = await res.json();
        if (json.success && json.data) {
            cachedShelters = json.data;
            renderShelterOverviewBars(cachedShelters);
            renderShelterCards(cachedShelters);
        }
    } catch (e) {
        console.error('Failed to load shelters:', e);
    }
}

function renderShelterOverviewBars(shelters) {
    const container = document.getElementById('overviewSheltersList');
    if (!container) return;

    container.innerHTML = shelters.map(s => {
        let barClass = 'fill-green';
        if (s.occupancyPercentage >= 90) barClass = 'fill-red';
        else if (s.occupancyPercentage >= 70) barClass = 'fill-amber';

        return `
            <div>
                <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px;">
                    <strong>${s.name}</strong>
                    <span>${s.currentOccupancy} / ${s.maxCapacity} (${s.occupancyPercentage}%)</span>
                </div>
                <div class="progress-track" style="margin:0;">
                    <div class="progress-fill ${barClass}" style="width: ${Math.min(100, s.occupancyPercentage)}%;"></div>
                </div>
            </div>
        `;
    }).join('');
}

function renderShelterCards(shelters) {
    const grid = document.getElementById('shelterCardsGrid');
    if (!grid) return;

    grid.innerHTML = shelters.map(s => `
        <div class="shelter-card">
            <div>
                <div class="resource-card-header">
                    <span class="badge badge-status">${s.shelterCode}</span>
                    <span class="badge ${s.status === 'FULL' ? 'badge-CRITICAL' : (s.status === 'NEAR_CAPACITY' ? 'badge-HIGH' : 'badge-LOW')}">${s.status}</span>
                </div>
                <div class="resource-card-title">${s.name}</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin:4px 0;"><i class="fa-solid fa-location-dot"></i> ${s.locationAddress}</div>
                
                <div class="progress-track">
                    <div class="progress-fill ${s.occupancyPercentage > 90 ? 'fill-red' : (s.occupancyPercentage > 70 ? 'fill-amber' : 'fill-green')}" style="width: ${s.occupancyPercentage}%;"></div>
                </div>
                <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:var(--text-secondary); margin-bottom:0.75rem;">
                    <span>Occupancy: <strong>${s.currentOccupancy} / ${s.maxCapacity}</strong></span>
                    <span>Free: <strong>${s.availableBeds} beds</strong></span>
                </div>

                <div style="font-size:0.75rem; color:var(--text-secondary); display:flex; gap:0.75rem;">
                    <span>${s.hasMedicalUnit ? '<i class="fa-solid fa-kit-medical text-danger"></i> Medical Ready' : '<i class="fa-solid fa-circle-xmark"></i> No Clinic'}</span>
                    <span>${s.hasFoodProvisions ? '<i class="fa-solid fa-bowl-food text-warning"></i> Rations Ready' : '<i class="fa-solid fa-circle-xmark"></i> No Food'}</span>
                </div>
            </div>
            <div style="margin-top:1rem;">
                <button class="btn btn-sm btn-primary" style="width:100%;" onclick="quickCheckInForShelter(${s.id})">
                    <i class="fa-solid fa-user-plus"></i> Check In Evacuees
                </button>
            </div>
        </div>
    `).join('');
}

// VOLUNTEERS
async function loadVolunteers() {
    try {
        const res = await fetch('/api/v1/volunteers');
        const json = await res.json();
        if (json.success && json.data) {
            cachedVolunteers = json.data;
            renderVolunteersTable(cachedVolunteers);
        }
    } catch (e) {
        console.error('Failed to load volunteers:', e);
    }
}

function renderVolunteersTable(volunteers) {
    const tbody = document.getElementById('volunteersTableBody');
    if (!tbody) return;

    tbody.innerHTML = volunteers.map(v => `
        <tr>
            <td><strong>${v.volunteerCode}</strong></td>
            <td><strong>${v.fullName}</strong></td>
            <td><span class="badge badge-status">${v.primarySkill}</span></td>
            <td>
                ${v.isAvailable 
                    ? '<span class="badge badge-LOW">STANDBY READY</span>' 
                    : '<span class="badge badge-HIGH">DEPLOYED</span>'}
            </td>
            <td>${v.email}<br><small style="color:var(--text-muted)">${v.phone}</small></td>
            <td>${v.isAvailable ? v.currentLocation : `Assigned to Incident #${v.currentAssignedIncidentId}`}</td>
            <td>
                ${v.isAvailable
                    ? `<button class="btn btn-sm btn-primary" onclick="deployVolunteerPrompt(${v.id})"><i class="fa-solid fa-paper-plane"></i> Deploy</button>`
                    : `<button class="btn btn-sm btn-outline" onclick="releaseVolunteer(${v.id})"><i class="fa-solid fa-rotate-left"></i> Standby</button>`
                }
            </td>
        </tr>
    `).join('');
}

async function deployVolunteerPrompt(volId) {
    const incIdStr = prompt("Enter Target Incident ID for deployment:");
    if (!incIdStr) return;
    const incId = parseInt(incIdStr, 10);
    if (isNaN(incId)) return;

    try {
        const res = await fetch(`/api/v1/volunteers/${volId}/assign/${incId}`, { method: 'POST' });
        const json = await res.json();
        if (json.success) {
            showToast('Deployed', `Volunteer deployed to Incident #${incId}`, 'SUCCESS');
            loadVolunteers();
            loadDashboardMetrics();
        } else {
            showToast('Error', json.message, 'CRITICAL');
        }
    } catch (e) {
        showToast('Error', 'Volunteer deployment failed', 'CRITICAL');
    }
}

async function releaseVolunteer(volId) {
    try {
        const res = await fetch(`/api/v1/volunteers/${volId}/release`, { method: 'POST' });
        const json = await res.json();
        if (json.success) {
            showToast('Standby', `Volunteer returned to standby pool`, 'SUCCESS');
            loadVolunteers();
            loadDashboardMetrics();
        }
    } catch (e) {
        showToast('Error', 'Failed to release volunteer', 'CRITICAL');
    }
}

// RECENT DISPATCHES
async function loadRecentDispatches() {
    try {
        const res = await fetch('/api/v1/dispatches/recent');
        const json = await res.json();
        if (json.success && json.data) {
            const tbody = document.getElementById('recentDispatchesBody');
            if (!tbody) return;
            tbody.innerHTML = json.data.map(d => `
                <tr>
                    <td><strong>${d.allocationCode}</strong></td>
                    <td>#${d.incidentId} - ${d.incidentTitle || 'Active Sector'}</td>
                    <td>${d.resourceName}</td>
                    <td><strong>${d.quantityDispatched}</strong> ${d.unit || ''}</td>
                    <td><span class="badge badge-HIGH">${d.dispatchStatus}</span></td>
                    <td>${new Date(d.dispatchedAt).toLocaleTimeString()}</td>
                </tr>
            `).join('');
        }
    } catch (e) {
        console.error('Failed to load dispatches:', e);
    }
}

// AUDIT LOGS
async function loadAuditLogs() {
    try {
        const res = await fetch('/api/v1/analytics/audit-logs');
        const json = await res.json();
        if (json.success && json.data) {
            const tbody = document.getElementById('auditTableBody');
            if (!tbody) return;
            tbody.innerHTML = json.data.map(a => `
                <tr>
                    <td>${new Date(a.timestamp).toLocaleString()}</td>
                    <td><span class="badge badge-status">${a.actionType}</span></td>
                    <td>${a.entityName}</td>
                    <td><strong>${a.entityIdentifier || '-'}</strong></td>
                    <td>${a.performedBy || 'COMMAND'}</td>
                    <td>${a.details}</td>
                </tr>
            `).join('');
        }
    } catch (e) {
        console.error('Failed to load audit logs:', e);
    }
}

// FORMS HANDLER
function initForms() {
    // Incident form
    const formInc = document.getElementById('formCreateIncident');
    if (formInc) {
        formInc.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                title: document.getElementById('incTitle').value,
                disasterType: document.getElementById('incType').value,
                severity: document.getElementById('incSeverity').value,
                locationName: document.getElementById('incLocation').value,
                affectedPopulation: parseInt(document.getElementById('incPopulation').value, 10) || 0,
                latitude: parseFloat(document.getElementById('incLat').value) || null,
                longitude: parseFloat(document.getElementById('incLng').value) || null,
                description: document.getElementById('incDesc').value,
                reportedBy: document.getElementById('incReportedBy').value,
                contactPhone: document.getElementById('incPhone').value
            };

            try {
                const res = await fetch('/api/v1/incidents', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    showToast('Incident Broadcasted', `Incident logged: ${json.data.incidentCode}`, 'CRITICAL');
                    closeModal('modalIncident');
                    formInc.reset();
                    loadIncidents();
                    loadDashboardMetrics();
                } else {
                    showToast('Submission Failed', json.message, 'CRITICAL');
                }
            } catch (err) {
                showToast('Network Error', 'Could not broadcast incident', 'CRITICAL');
            }
        });
    }

    // Dispatch form
    const formDisp = document.getElementById('formDispatchResource');
    if (formDisp) {
        formDisp.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                incidentId: parseInt(document.getElementById('dispIncidentSelect').value, 10),
                resourceId: parseInt(document.getElementById('dispResourceSelect').value, 10),
                quantity: parseInt(document.getElementById('dispQuantity').value, 10),
                dispatchedBy: document.getElementById('dispOfficer').value,
                notes: document.getElementById('dispNotes').value
            };

            try {
                const res = await fetch('/api/v1/dispatches', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    showToast('Dispatch En Route', `Convoy ${json.data.allocationCode} dispatched!`, 'SUCCESS');
                    closeModal('modalDispatch');
                    formDisp.reset();
                    loadRecentDispatches();
                    loadResources();
                    loadDashboardMetrics();
                } else {
                    showToast('Dispatch Error', json.message, 'CRITICAL');
                }
            } catch (err) {
                showToast('Dispatch Error', 'Communication error with logistics service', 'CRITICAL');
            }
        });
    }

    // Shelter check-in form
    const formChk = document.getElementById('formCheckIn');
    if (formChk) {
        formChk.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                shelterId: parseInt(document.getElementById('checkInShelterSelect').value, 10),
                evacueeCount: parseInt(document.getElementById('checkInCount').value, 10),
                notes: document.getElementById('checkInNotes').value
            };

            try {
                const res = await fetch('/api/v1/shelters/check-in', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    showToast('Check-In Complete', `Processed ${payload.evacueeCount} evacuees`, 'SUCCESS');
                    closeModal('modalCheckIn');
                    formChk.reset();
                    loadShelters();
                    loadDashboardMetrics();
                } else {
                    showToast('Capacity Limit', json.message, 'CRITICAL');
                }
            } catch (err) {
                showToast('Error', 'Intake check-in failed', 'CRITICAL');
            }
        });
    }

    // Volunteer form
    const formVol = document.getElementById('formVolunteer');
    if (formVol) {
        formVol.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                fullName: document.getElementById('volName').value,
                email: document.getElementById('volEmail').value,
                phone: document.getElementById('volPhone').value,
                primarySkill: document.getElementById('volSkill').value,
                currentLocation: document.getElementById('volLocation').value
            };

            try {
                const res = await fetch('/api/v1/volunteers/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    showToast('Personnel Enlisted', `${payload.fullName} is now registered`, 'SUCCESS');
                    closeModal('modalVolunteer');
                    formVol.reset();
                    loadVolunteers();
                    loadDashboardMetrics();
                } else {
                    showToast('Error', json.message, 'CRITICAL');
                }
            } catch (err) {
                showToast('Error', 'Volunteer registration failed', 'CRITICAL');
            }
        });
    }
}

// QUICK ACTIONS
function openDispatchModal() {
    populateDispatchSelects();
    openModal('modalDispatch');
}

function quickDispatchToIncident(incidentId) {
    populateDispatchSelects(incidentId);
    openModal('modalDispatch');
}

function openDispatchForResource(resourceId) {
    populateDispatchSelects(null, resourceId);
    openModal('modalDispatch');
}

function populateDispatchSelects(presetIncId = null, presetResId = null) {
    const incSel = document.getElementById('dispIncidentSelect');
    const resSel = document.getElementById('dispResourceSelect');
    if (!incSel || !resSel) return;

    incSel.innerHTML = cachedIncidents
        .filter(i => i.status !== 'RESOLVED')
        .map(i => `<option value="${i.id}" ${i.id === presetIncId ? 'selected' : ''}>[${i.severity}] ${i.incidentCode}: ${i.title}</option>`)
        .join('');

    resSel.innerHTML = cachedResources
        .map(r => `<option value="${r.id}" ${r.id === presetResId ? 'selected' : ''}>${r.name} (Avail: ${r.availableQuantity} ${r.unit})</option>`)
        .join('');
}

function openCheckInModal() {
    populateCheckInShelters();
    openModal('modalCheckIn');
}

function quickCheckInForShelter(shelterId) {
    populateCheckInShelters(shelterId);
    openModal('modalCheckIn');
}

function populateCheckInShelters(presetShelterId = null) {
    const sel = document.getElementById('checkInShelterSelect');
    if (!sel) return;
    sel.innerHTML = cachedShelters
        .filter(s => s.status !== 'CLOSED')
        .map(s => `<option value="${s.id}" ${s.id === presetShelterId ? 'selected' : ''}>${s.name} (${s.availableBeds} beds available - ${s.status})</option>`)
        .join('');
}

// TOAST NOTIFIER
function showToast(title, message, severity = 'INFO') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${severity}`;
    toast.innerHTML = `
        <i class="fa-solid fa-bell"></i>
        <div>
            <strong>${title}</strong>
            <p style="margin-top:2px; font-size:0.75rem; color:var(--text-secondary);">${message}</p>
        </div>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}
