package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.database.entity.enums.ResourceCategory;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.ResourceResponse;
import com.disasterrelief.hub.service.ResourceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/resources")
@CrossOrigin(origins = "*")
public class ResourceController {

    private final ResourceService resourceService;

    public ResourceController(ResourceService resourceService) {
        this.resourceService = resourceService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ResourceResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(resourceService.getAllResources()));
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<ApiResponse<List<ResourceResponse>>> getByCategory(@PathVariable ResourceCategory category) {
        return ResponseEntity.ok(ApiResponse.success(resourceService.getResourcesByCategory(category)));
    }

    @GetMapping("/low-stock")
    public ResponseEntity<ApiResponse<List<ResourceResponse>>> getLowStock() {
        return ResponseEntity.ok(ApiResponse.success(resourceService.getLowStockAlerts()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ResourceResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(resourceService.getResourceById(id)));
    }

    @PostMapping("/{id}/restock")
    public ResponseEntity<ApiResponse<ResourceResponse>> restock(
            @PathVariable Long id,
            @RequestParam int quantity) {
        ResourceResponse restocked = resourceService.restockResource(id, quantity);
        return ResponseEntity.ok(ApiResponse.success("Successfully restocked " + quantity + " units", restocked));
    }
}
