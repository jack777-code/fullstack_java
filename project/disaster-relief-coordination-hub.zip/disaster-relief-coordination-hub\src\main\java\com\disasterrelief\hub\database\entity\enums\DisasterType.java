package com.disasterrelief.hub.database.entity.enums;

public enum DisasterType {
    FLOOD,
    EARTHQUAKE,
    HURRICANE,
    WILDFIRE,
    TSUNAMI,
    LANDSLIDE,
    INDUSTRIAL_HAZARD
}
