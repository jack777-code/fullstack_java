package com.disasterrelief.hub.presentation.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class ShelterCheckInRequest {

    @NotNull(message = "Shelter ID is required")
    private Long shelterId;

    @NotNull(message = "Number of evacuees is required")
    @Min(value = 1, message = "Must check in at least 1 person")
    private Integer evacueeCount;

    private String notes;

    public ShelterCheckInRequest() {
    }

    public ShelterCheckInRequest(Long shelterId, Integer evacueeCount, String notes) {
        this.shelterId = shelterId;
        this.evacueeCount = evacueeCount;
        this.notes = notes;
    }

    public Long getShelterId() {
        return shelterId;
    }

    public void setShelterId(Long shelterId) {
        this.shelterId = shelterId;
    }

    public Integer getEvacueeCount() {
        return evacueeCount;
    }

    public void setEvacueeCount(Integer evacueeCount) {
        this.evacueeCount = evacueeCount;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
