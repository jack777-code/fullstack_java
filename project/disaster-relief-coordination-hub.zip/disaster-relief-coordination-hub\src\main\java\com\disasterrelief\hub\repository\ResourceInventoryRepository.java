package com.disasterrelief.hub.repository;

import com.disasterrelief.hub.database.entity.ResourceInventoryEntity;
import com.disasterrelief.hub.database.entity.enums.ResourceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResourceInventoryRepository extends JpaRepository<ResourceInventoryEntity, Long> {

    Optional<ResourceInventoryEntity> findByResourceCode(String resourceCode);

    List<ResourceInventoryEntity> findByCategory(ResourceCategory category);

    @Query("SELECT r FROM ResourceInventoryEntity r WHERE r.availableQuantity <= r.minimumThreshold")
    List<ResourceInventoryEntity> findLowStockResources();

    @Query("SELECT COALESCE(SUM(r.totalQuantity), 0) FROM ResourceInventoryEntity r")
    long sumTotalInventory();

    @Query("SELECT COALESCE(SUM(r.allocatedQuantity), 0) FROM ResourceInventoryEntity r")
    long sumAllocatedInventory();
}
