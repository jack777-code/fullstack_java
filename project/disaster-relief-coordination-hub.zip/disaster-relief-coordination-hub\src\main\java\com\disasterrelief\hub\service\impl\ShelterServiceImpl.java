package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.database.entity.ShelterEntity;
import com.disasterrelief.hub.database.entity.enums.ShelterStatus;
import com.disasterrelief.hub.presentation.dto.request.ShelterCheckInRequest;
import com.disasterrelief.hub.presentation.dto.response.ShelterResponse;
import com.disasterrelief.hub.presentation.exception.ResourceNotFoundException;
import com.disasterrelief.hub.presentation.exception.ShelterFullException;
import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.ShelterRepository;
import com.disasterrelief.hub.service.NotificationService;
import com.disasterrelief.hub.service.ShelterService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ShelterServiceImpl implements ShelterService {

    private final ShelterRepository shelterRepository;
    private final AuditLogRepository auditLogRepository;
    private final NotificationService notificationService;

    public ShelterServiceImpl(ShelterRepository shelterRepository,
                              AuditLogRepository auditLogRepository,
                              NotificationService notificationService) {
        this.shelterRepository = shelterRepository;
        this.auditLogRepository = auditLogRepository;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ShelterResponse> getAllShelters() {
        return shelterRepository.findAll().stream()
                .map(ShelterResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ShelterResponse> getAvailableShelters() {
        return shelterRepository.findAvailableShelters().stream()
                .map(ShelterResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ShelterResponse getShelterById(Long id) {
        ShelterEntity shelter = shelterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shelter not found with ID: " + id));
        return ShelterResponse.fromEntity(shelter);
    }

    @Override
    public ShelterResponse checkInEvacuees(ShelterCheckInRequest request) {
        ShelterEntity shelter = shelterRepository.findById(request.getShelterId())
                .orElseThrow(() -> new ResourceNotFoundException("Shelter not found with ID: " + request.getShelterId()));

        int newTotal = shelter.getCurrentOccupancy() + request.getEvacueeCount();
        if (newTotal > shelter.getMaxCapacity()) {
            throw new ShelterFullException("Cannot check in " + request.getEvacueeCount() 
                    + " evacuees. Shelter capacity exceeded! Remaining capacity: " 
                    + (shelter.getMaxCapacity() - shelter.getCurrentOccupancy()));
        }

        shelter.setCurrentOccupancy(newTotal);
        if (newTotal == shelter.getMaxCapacity()) {
            shelter.setStatus(ShelterStatus.FULL);
        } else if (newTotal >= (shelter.getMaxCapacity() * 0.9)) {
            shelter.setStatus(ShelterStatus.NEAR_CAPACITY);
        }

        ShelterEntity updated = shelterRepository.save(shelter);

        auditLogRepository.save(new AuditLogEntity(
                "SHELTER_CHECKIN",
                "Shelter",
                shelter.getShelterCode(),
                "Checked in " + request.getEvacueeCount() + " evacuees. Current count: " + newTotal + "/" + shelter.getMaxCapacity(),
                "SHELTER_MARSHAL"
        ));

        if (shelter.getStatus() == ShelterStatus.FULL || shelter.getStatus() == ShelterStatus.NEAR_CAPACITY) {
            notificationService.broadcastAlert(new EmergencyAlertMessage(
                    "SHELTER_ALERT",
                    "Shelter Alert: " + shelter.getName(),
                    "Occupancy reached " + shelter.getCurrentOccupancy() + "/" + shelter.getMaxCapacity() + " (" + shelter.getStatus() + ")",
                    "HIGH"
            ));
        }

        notificationService.notifyMetricsChanged();
        return ShelterResponse.fromEntity(updated);
    }

    @Override
    public ShelterResponse updateShelterStatus(Long id, ShelterStatus status) {
        ShelterEntity shelter = shelterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shelter not found with ID: " + id));

        shelter.setStatus(status);
        ShelterEntity updated = shelterRepository.save(shelter);

        auditLogRepository.save(new AuditLogEntity(
                "SHELTER_STATUS_UPDATE",
                "Shelter",
                shelter.getShelterCode(),
                "Status changed to " + status,
                "INCIDENT_COMMANDER"
        ));

        notificationService.notifyMetricsChanged();
        return ShelterResponse.fromEntity(updated);
    }
}
