-- Enterprise DDL Schema for Disaster Relief Coordination Hub
-- Compatible with H2, PostgreSQL, and MySQL

CREATE TABLE IF NOT EXISTS incidents (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    incident_code VARCHAR(32) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    disaster_type VARCHAR(30) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL,
    affected_population INT DEFAULT 0,
    location_name VARCHAR(150) NOT NULL,
    latitude DOUBLE,
    longitude DOUBLE,
    description VARCHAR(2000),
    reported_by VARCHAR(100),
    contact_phone VARCHAR(30),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS resource_inventory (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    resource_code VARCHAR(32) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(30) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    total_quantity INT NOT NULL,
    allocated_quantity INT NOT NULL DEFAULT 0,
    available_quantity INT NOT NULL,
    warehouse_location VARCHAR(150) NOT NULL,
    minimum_threshold INT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shelters (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    shelter_code VARCHAR(32) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    location_address VARCHAR(200) NOT NULL,
    latitude DOUBLE,
    longitude DOUBLE,
    max_capacity INT NOT NULL,
    current_occupancy INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    contact_person VARCHAR(100),
    contact_phone VARCHAR(30),
    has_medical_unit BOOLEAN DEFAULT FALSE,
    has_food_provisions BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS volunteers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    volunteer_code VARCHAR(32) NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    primary_skill VARCHAR(40) NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    current_assigned_incident_id BIGINT,
    current_location VARCHAR(120),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dispatch_allocations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    allocation_code VARCHAR(32) NOT NULL UNIQUE,
    incident_id BIGINT NOT NULL,
    resource_id BIGINT NOT NULL,
    quantity_dispatched INT NOT NULL,
    dispatch_status VARCHAR(30) NOT NULL,
    dispatched_at TIMESTAMP,
    dispatched_by VARCHAR(100),
    notes VARCHAR(500),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP,
    CONSTRAINT fk_dispatch_incident FOREIGN KEY (incident_id) REFERENCES incidents(id),
    CONSTRAINT fk_dispatch_resource FOREIGN KEY (resource_id) REFERENCES resource_inventory(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    action_type VARCHAR(60) NOT NULL,
    entity_name VARCHAR(60) NOT NULL,
    entity_identifier VARCHAR(60),
    details VARCHAR(1000),
    performed_by VARCHAR(80),
    timestamp TIMESTAMP NOT NULL
);
