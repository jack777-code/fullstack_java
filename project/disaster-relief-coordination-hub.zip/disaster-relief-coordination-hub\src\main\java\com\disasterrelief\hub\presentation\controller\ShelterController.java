package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.database.entity.enums.ShelterStatus;
import com.disasterrelief.hub.presentation.dto.request.ShelterCheckInRequest;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.ShelterResponse;
import com.disasterrelief.hub.service.ShelterService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/shelters")
@CrossOrigin(origins = "*")
public class ShelterController {

    private final ShelterService shelterService;

    public ShelterController(ShelterService shelterService) {
        this.shelterService = shelterService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ShelterResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(shelterService.getAllShelters()));
    }

    @GetMapping("/available")
    public ResponseEntity<ApiResponse<List<ShelterResponse>>> getAvailable() {
        return ResponseEntity.ok(ApiResponse.success(shelterService.getAvailableShelters()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ShelterResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(shelterService.getShelterById(id)));
    }

    @PostMapping("/check-in")
    public ResponseEntity<ApiResponse<ShelterResponse>> checkInEvacuees(@Valid @RequestBody ShelterCheckInRequest request) {
        ShelterResponse updated = shelterService.checkInEvacuees(request);
        return ResponseEntity.ok(ApiResponse.success("Evacuees checked in successfully", updated));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<ShelterResponse>> updateStatus(
            @PathVariable Long id,
            @RequestParam ShelterStatus status) {
        ShelterResponse updated = shelterService.updateShelterStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Shelter status updated to " + status, updated));
    }
}
