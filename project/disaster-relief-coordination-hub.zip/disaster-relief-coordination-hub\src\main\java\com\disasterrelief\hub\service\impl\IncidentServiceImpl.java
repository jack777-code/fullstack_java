package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.database.entity.IncidentEntity;
import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.presentation.dto.request.IncidentCreateRequest;
import com.disasterrelief.hub.presentation.dto.response.IncidentResponse;
import com.disasterrelief.hub.presentation.exception.ResourceNotFoundException;
import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.IncidentRepository;
import com.disasterrelief.hub.service.IncidentService;
import com.disasterrelief.hub.service.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class IncidentServiceImpl implements IncidentService {

    private final IncidentRepository incidentRepository;
    private final AuditLogRepository auditLogRepository;
    private final NotificationService notificationService;

    public IncidentServiceImpl(IncidentRepository incidentRepository,
                               AuditLogRepository auditLogRepository,
                               NotificationService notificationService) {
        this.incidentRepository = incidentRepository;
        this.auditLogRepository = auditLogRepository;
        this.notificationService = notificationService;
    }

    @Override
    public IncidentResponse reportIncident(IncidentCreateRequest request) {
        String code = "INC-" + Year.now().getValue() + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        IncidentEntity entity = new IncidentEntity(
                code,
                request.getTitle(),
                request.getDisasterType(),
                request.getSeverity(),
                IncidentStatus.REPORTED,
                request.getAffectedPopulation() != null ? request.getAffectedPopulation() : 0,
                request.getLocationName(),
                request.getLatitude(),
                request.getLongitude(),
                request.getDescription(),
                request.getReportedBy(),
                request.getContactPhone()
        );

        IncidentEntity saved = incidentRepository.save(entity);

        // Audit Trail
        auditLogRepository.save(new AuditLogEntity(
                "INCIDENT_REPORTED",
                "Incident",
                saved.getIncidentCode(),
                "New incident logged: " + saved.getTitle() + " [" + saved.getSeverity() + "]",
                request.getReportedBy() != null ? request.getReportedBy() : "ANONYMOUS_DISPATCH"
        ));

        IncidentResponse response = IncidentResponse.fromEntity(saved);

        // Real-Time Notification Broadcast
        notificationService.notifyIncidentCreated(response);
        notificationService.broadcastAlert(new EmergencyAlertMessage(
                "NEW_INCIDENT",
                "New " + saved.getDisasterType() + " Reported!",
                saved.getTitle() + " at " + saved.getLocationName(),
                saved.getSeverity().name()
        ));
        notificationService.notifyMetricsChanged();

        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidentResponse> getAllIncidents() {
        return incidentRepository.findAll().stream()
                .map(IncidentResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidentResponse> getActiveTriageIncidents() {
        return incidentRepository.findAllActiveTriageIncidents().stream()
                .map(IncidentResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public IncidentResponse getIncidentById(Long id) {
        IncidentEntity entity = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident not found with ID: " + id));
        return IncidentResponse.fromEntity(entity);
    }

    @Override
    public IncidentResponse updateIncidentStatus(Long id, IncidentStatus newStatus) {
        IncidentEntity entity = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident not found with ID: " + id));

        IncidentStatus oldStatus = entity.getStatus();
        entity.setStatus(newStatus);
        IncidentEntity updated = incidentRepository.save(entity);

        auditLogRepository.save(new AuditLogEntity(
                "INCIDENT_STATUS_CHANGE",
                "Incident",
                entity.getIncidentCode(),
                "Status transitioned from " + oldStatus + " to " + newStatus,
                "OPERATIONS_COMMAND"
        ));

        IncidentResponse response = IncidentResponse.fromEntity(updated);
        notificationService.notifyIncidentCreated(response);
        notificationService.notifyMetricsChanged();

        return response;
    }
}
