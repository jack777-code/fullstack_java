package com.disasterrelief.hub.repository;

import com.disasterrelief.hub.database.entity.ShelterEntity;
import com.disasterrelief.hub.database.entity.enums.ShelterStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShelterRepository extends JpaRepository<ShelterEntity, Long> {

    Optional<ShelterEntity> findByShelterCode(String shelterCode);

    List<ShelterEntity> findByStatus(ShelterStatus status);

    @Query("SELECT s FROM ShelterEntity s WHERE s.currentOccupancy < s.maxCapacity AND s.status != 'CLOSED'")
    List<ShelterEntity> findAvailableShelters();

    @Query("SELECT COALESCE(SUM(s.maxCapacity), 0) FROM ShelterEntity s")
    long sumTotalCapacity();

    @Query("SELECT COALESCE(SUM(s.currentOccupancy), 0) FROM ShelterEntity s")
    long sumCurrentOccupancy();
}
