package com.disasterrelief.hub.database.entity.enums;

public enum VolunteerSkill {
    PARAMEDIC,
    SEARCH_AND_RESCUE,
    HEAVY_MACHINERY,
    LOGISTICS,
    COUNSELING,
    DRONE_OPERATOR
}
