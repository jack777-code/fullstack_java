package com.disasterrelief.hub.presentation.dto.request;

import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class VolunteerRegisterRequest {

    @NotBlank(message = "Full name is required")
    @Size(max = 120, message = "Name must be less than 120 characters")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @NotNull(message = "Primary skill is required")
    private VolunteerSkill primarySkill;

    private String currentLocation;

    public VolunteerRegisterRequest() {
    }

    public VolunteerRegisterRequest(String fullName, String email, String phone, VolunteerSkill primarySkill, String currentLocation) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.primarySkill = primarySkill;
        this.currentLocation = currentLocation;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public VolunteerSkill getPrimarySkill() {
        return primarySkill;
    }

    public void setPrimarySkill(VolunteerSkill primarySkill) {
        this.primarySkill = primarySkill;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }
}
