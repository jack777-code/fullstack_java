package com.disasterrelief.hub.service;

import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import com.disasterrelief.hub.presentation.dto.request.VolunteerRegisterRequest;
import com.disasterrelief.hub.presentation.dto.response.VolunteerResponse;

import java.util.List;

public interface VolunteerService {
    List<VolunteerResponse> getAllVolunteers();
    List<VolunteerResponse> getAvailableVolunteers();
    List<VolunteerResponse> getAvailableBySkill(VolunteerSkill skill);
    VolunteerResponse registerVolunteer(VolunteerRegisterRequest request);
    VolunteerResponse assignToIncident(Long volunteerId, Long incidentId);
    VolunteerResponse releaseVolunteer(Long volunteerId);
}
