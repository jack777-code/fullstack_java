package com.disasterrelief.hub.database.entity.enums;

public enum SeverityLevel {
    CRITICAL(4),
    HIGH(3),
    MODERATE(2),
    LOW(1);

    private final int weight;

    SeverityLevel(int weight) {
        this.weight = weight;
    }

    public int getWeight() {
        return weight;
    }
}
