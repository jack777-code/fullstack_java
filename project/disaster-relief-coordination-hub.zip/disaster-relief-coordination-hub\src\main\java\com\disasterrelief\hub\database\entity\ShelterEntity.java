package com.disasterrelief.hub.database.entity;

import com.disasterrelief.hub.database.entity.enums.ShelterStatus;
import jakarta.persistence.*;

@Entity
@Table(name = "shelters")
public class ShelterEntity extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "shelter_code", nullable = false, unique = true, length = 32)
    private String shelterCode;

    @Column(name = "name", nullable = false, length = 150)
    private String name;

    @Column(name = "location_address", nullable = false, length = 200)
    private String locationAddress;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "max_capacity", nullable = false)
    private Integer maxCapacity;

    @Column(name = "current_occupancy", nullable = false)
    private Integer currentOccupancy;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private ShelterStatus status;

    @Column(name = "contact_person", length = 100)
    private String contactPerson;

    @Column(name = "contact_phone", length = 30)
    private String contactPhone;

    @Column(name = "has_medical_unit", nullable = false)
    private Boolean hasMedicalUnit = false;

    @Column(name = "has_food_provisions", nullable = false)
    private Boolean hasFoodProvisions = true;

    public ShelterEntity() {
    }

    public ShelterEntity(String shelterCode, String name, String locationAddress, Double latitude, Double longitude,
                         Integer maxCapacity, Integer currentOccupancy, ShelterStatus status,
                         String contactPerson, String contactPhone, Boolean hasMedicalUnit, Boolean hasFoodProvisions) {
        this.shelterCode = shelterCode;
        this.name = name;
        this.locationAddress = locationAddress;
        this.latitude = latitude;
        this.longitude = longitude;
        this.maxCapacity = maxCapacity;
        this.currentOccupancy = currentOccupancy;
        this.status = status;
        this.contactPerson = contactPerson;
        this.contactPhone = contactPhone;
        this.hasMedicalUnit = hasMedicalUnit != null ? hasMedicalUnit : false;
        this.hasFoodProvisions = hasFoodProvisions != null ? hasFoodProvisions : true;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShelterCode() {
        return shelterCode;
    }

    public void setShelterCode(String shelterCode) {
        this.shelterCode = shelterCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocationAddress() {
        return locationAddress;
    }

    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Integer getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public Integer getCurrentOccupancy() {
        return currentOccupancy;
    }

    public void setCurrentOccupancy(Integer currentOccupancy) {
        this.currentOccupancy = currentOccupancy;
    }

    public ShelterStatus getStatus() {
        return status;
    }

    public void setStatus(ShelterStatus status) {
        this.status = status;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public Boolean getHasMedicalUnit() {
        return hasMedicalUnit;
    }

    public void setHasMedicalUnit(Boolean hasMedicalUnit) {
        this.hasMedicalUnit = hasMedicalUnit;
    }

    public Boolean getHasFoodProvisions() {
        return hasFoodProvisions;
    }

    public void setHasFoodProvisions(Boolean hasFoodProvisions) {
        this.hasFoodProvisions = hasFoodProvisions;
    }
}
