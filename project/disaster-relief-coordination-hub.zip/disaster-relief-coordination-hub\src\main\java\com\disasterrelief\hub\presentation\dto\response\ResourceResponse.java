package com.disasterrelief.hub.presentation.dto.response;

import com.disasterrelief.hub.database.entity.ResourceInventoryEntity;
import com.disasterrelief.hub.database.entity.enums.ResourceCategory;

public class ResourceResponse {

    private Long id;
    private String resourceCode;
    private String name;
    private ResourceCategory category;
    private String unit;
    private Integer totalQuantity;
    private Integer allocatedQuantity;
    private Integer availableQuantity;
    private String warehouseLocation;
    private Integer minimumThreshold;
    private boolean isLowStock;

    public ResourceResponse() {
    }

    public static ResourceResponse fromEntity(ResourceInventoryEntity entity) {
        if (entity == null) return null;
        ResourceResponse dto = new ResourceResponse();
        dto.setId(entity.getId());
        dto.setResourceCode(entity.getResourceCode());
        dto.setName(entity.getName());
        dto.setCategory(entity.getCategory());
        dto.setUnit(entity.getUnit());
        dto.setTotalQuantity(entity.getTotalQuantity());
        dto.setAllocatedQuantity(entity.getAllocatedQuantity());
        dto.setAvailableQuantity(entity.getAvailableQuantity());
        dto.setWarehouseLocation(entity.getWarehouseLocation());
        dto.setMinimumThreshold(entity.getMinimumThreshold());
        dto.setLowStock(entity.getAvailableQuantity() <= entity.getMinimumThreshold());
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ResourceCategory getCategory() {
        return category;
    }

    public void setCategory(ResourceCategory category) {
        this.category = category;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public Integer getAllocatedQuantity() {
        return allocatedQuantity;
    }

    public void setAllocatedQuantity(Integer allocatedQuantity) {
        this.allocatedQuantity = allocatedQuantity;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public String getWarehouseLocation() {
        return warehouseLocation;
    }

    public void setWarehouseLocation(String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    public Integer getMinimumThreshold() {
        return minimumThreshold;
    }

    public void setMinimumThreshold(Integer minimumThreshold) {
        this.minimumThreshold = minimumThreshold;
    }

    public boolean isLowStock() {
        return isLowStock;
    }

    public void setLowStock(boolean lowStock) {
        isLowStock = lowStock;
    }
}
