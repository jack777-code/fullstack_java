package com.disasterrelief.hub.database.entity;

import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import jakarta.persistence.*;

@Entity
@Table(name = "volunteers")
public class VolunteerEntity extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "volunteer_code", nullable = false, unique = true, length = 32)
    private String volunteerCode;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Column(name = "phone", nullable = false, length = 30)
    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(name = "primary_skill", nullable = false, length = 40)
    private VolunteerSkill primarySkill;

    @Column(name = "is_available", nullable = false)
    private Boolean isAvailable = true;

    @Column(name = "current_assigned_incident_id")
    private Long currentAssignedIncidentId;

    @Column(name = "current_location", length = 120)
    private String currentLocation;

    public VolunteerEntity() {
    }

    public VolunteerEntity(String volunteerCode, String fullName, String email, String phone,
                           VolunteerSkill primarySkill, Boolean isAvailable,
                           Long currentAssignedIncidentId, String currentLocation) {
        this.volunteerCode = volunteerCode;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.primarySkill = primarySkill;
        this.isAvailable = isAvailable != null ? isAvailable : true;
        this.currentAssignedIncidentId = currentAssignedIncidentId;
        this.currentLocation = currentLocation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVolunteerCode() {
        return volunteerCode;
    }

    public void setVolunteerCode(String volunteerCode) {
        this.volunteerCode = volunteerCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public VolunteerSkill getPrimarySkill() {
        return primarySkill;
    }

    public void setPrimarySkill(VolunteerSkill primarySkill) {
        this.primarySkill = primarySkill;
    }

    public Boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(Boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Long getCurrentAssignedIncidentId() {
        return currentAssignedIncidentId;
    }

    public void setCurrentAssignedIncidentId(Long currentAssignedIncidentId) {
        this.currentAssignedIncidentId = currentAssignedIncidentId;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }
}
