package com.disasterrelief.hub.service;

import com.disasterrelief.hub.database.entity.enums.ResourceCategory;
import com.disasterrelief.hub.presentation.dto.response.ResourceResponse;

import java.util.List;

public interface ResourceService {
    List<ResourceResponse> getAllResources();
    List<ResourceResponse> getResourcesByCategory(ResourceCategory category);
    List<ResourceResponse> getLowStockAlerts();
    ResourceResponse restockResource(Long resourceId, int quantity);
    ResourceResponse getResourceById(Long resourceId);
}
