package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.service.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationServiceImpl implements NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationServiceImpl.class);
    private final SimpMessagingTemplate messagingTemplate;

    public NotificationServiceImpl(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    public void broadcastAlert(EmergencyAlertMessage message) {
        log.info("Broadcasting emergency alert: [{}] {}", message.getSeverity(), message.getTitle());
        messagingTemplate.convertAndSend("/topic/alerts", message);
    }

    @Override
    public void notifyIncidentCreated(Object incident) {
        log.info("Publishing real-time incident event");
        messagingTemplate.convertAndSend("/topic/incidents", incident);
    }

    @Override
    public void notifyResourceUpdated(Object resource) {
        log.info("Publishing resource update event");
        messagingTemplate.convertAndSend("/topic/resources", resource);
    }

    @Override
    public void notifyMetricsChanged() {
        messagingTemplate.convertAndSend("/topic/metrics-trigger", "REFRESH");
    }
}
