package com.disasterrelief.hub.database.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "dispatch_allocations")
public class DispatchAllocationEntity extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "allocation_code", nullable = false, unique = true, length = 32)
    private String allocationCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_id", nullable = false)
    private IncidentEntity incident;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "resource_id", nullable = false)
    private ResourceInventoryEntity resource;

    @Column(name = "quantity_dispatched", nullable = false)
    private Integer quantityDispatched;

    @Column(name = "dispatch_status", nullable = false, length = 30)
    private String dispatchStatus; // e.g. PENDING, EN_ROUTE, DELIVERED, CANCELLED

    @Column(name = "dispatched_at")
    private LocalDateTime dispatchedAt;

    @Column(name = "dispatched_by", length = 100)
    private String dispatchedBy;

    @Column(name = "notes", length = 500)
    private String notes;

    public DispatchAllocationEntity() {
    }

    public DispatchAllocationEntity(String allocationCode, IncidentEntity incident, ResourceInventoryEntity resource,
                                    Integer quantityDispatched, String dispatchStatus, LocalDateTime dispatchedAt,
                                    String dispatchedBy, String notes) {
        this.allocationCode = allocationCode;
        this.incident = incident;
        this.resource = resource;
        this.quantityDispatched = quantityDispatched;
        this.dispatchStatus = dispatchStatus;
        this.dispatchedAt = dispatchedAt;
        this.dispatchedBy = dispatchedBy;
        this.notes = notes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAllocationCode() {
        return allocationCode;
    }

    public void setAllocationCode(String allocationCode) {
        this.allocationCode = allocationCode;
    }

    public IncidentEntity getIncident() {
        return incident;
    }

    public void setIncident(IncidentEntity incident) {
        this.incident = incident;
    }

    public ResourceInventoryEntity getResource() {
        return resource;
    }

    public void setResource(ResourceInventoryEntity resource) {
        this.resource = resource;
    }

    public Integer getQuantityDispatched() {
        return quantityDispatched;
    }

    public void setQuantityDispatched(Integer quantityDispatched) {
        this.quantityDispatched = quantityDispatched;
    }

    public String getDispatchStatus() {
        return dispatchStatus;
    }

    public void setDispatchStatus(String dispatchStatus) {
        this.dispatchStatus = dispatchStatus;
    }

    public LocalDateTime getDispatchedAt() {
        return dispatchedAt;
    }

    public void setDispatchedAt(LocalDateTime dispatchedAt) {
        this.dispatchedAt = dispatchedAt;
    }

    public String getDispatchedBy() {
        return dispatchedBy;
    }

    public void setDispatchedBy(String dispatchedBy) {
        this.dispatchedBy = dispatchedBy;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
