package com.disasterrelief.hub.repository;

import com.disasterrelief.hub.database.entity.DispatchAllocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DispatchAllocationRepository extends JpaRepository<DispatchAllocationEntity, Long> {

    Optional<DispatchAllocationEntity> findByAllocationCode(String allocationCode);

    List<DispatchAllocationEntity> findByIncidentId(Long incidentId);

    List<DispatchAllocationEntity> findTop15ByOrderByCreatedAtDesc();
}
