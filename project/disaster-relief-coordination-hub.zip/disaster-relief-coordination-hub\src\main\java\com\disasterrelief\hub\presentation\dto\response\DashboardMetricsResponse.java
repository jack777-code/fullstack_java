package com.disasterrelief.hub.presentation.dto.response;

public class DashboardMetricsResponse {

    private long totalIncidents;
    private long activeIncidents;
    private long criticalIncidents;
    private long totalAffectedPopulation;
    private long totalShelterCapacity;
    private long currentShelterOccupancy;
    private double overallShelterOccupancyRate;
    private long availableVolunteers;
    private long totalSuppliesInStock;
    private long lowStockAlertsCount;
    private int disasterReadinessIndex; // 0 - 100%

    public DashboardMetricsResponse() {
    }

    public long getTotalIncidents() {
        return totalIncidents;
    }

    public void setTotalIncidents(long totalIncidents) {
        this.totalIncidents = totalIncidents;
    }

    public long getActiveIncidents() {
        return activeIncidents;
    }

    public void setActiveIncidents(long activeIncidents) {
        this.activeIncidents = activeIncidents;
    }

    public long getCriticalIncidents() {
        return criticalIncidents;
    }

    public void setCriticalIncidents(long criticalIncidents) {
        this.criticalIncidents = criticalIncidents;
    }

    public long getTotalAffectedPopulation() {
        return totalAffectedPopulation;
    }

    public void setTotalAffectedPopulation(long totalAffectedPopulation) {
        this.totalAffectedPopulation = totalAffectedPopulation;
    }

    public long getTotalShelterCapacity() {
        return totalShelterCapacity;
    }

    public void setTotalShelterCapacity(long totalShelterCapacity) {
        this.totalShelterCapacity = totalShelterCapacity;
    }

    public long getCurrentShelterOccupancy() {
        return currentShelterOccupancy;
    }

    public void setCurrentShelterOccupancy(long currentShelterOccupancy) {
        this.currentShelterOccupancy = currentShelterOccupancy;
    }

    public double getOverallShelterOccupancyRate() {
        return overallShelterOccupancyRate;
    }

    public void setOverallShelterOccupancyRate(double overallShelterOccupancyRate) {
        this.overallShelterOccupancyRate = overallShelterOccupancyRate;
    }

    public long getAvailableVolunteers() {
        return availableVolunteers;
    }

    public void setAvailableVolunteers(long availableVolunteers) {
        this.availableVolunteers = availableVolunteers;
    }

    public long getTotalSuppliesInStock() {
        return totalSuppliesInStock;
    }

    public void setTotalSuppliesInStock(long totalSuppliesInStock) {
        this.totalSuppliesInStock = totalSuppliesInStock;
    }

    public long getLowStockAlertsCount() {
        return lowStockAlertsCount;
    }

    public void setLowStockAlertsCount(long lowStockAlertsCount) {
        this.lowStockAlertsCount = lowStockAlertsCount;
    }

    public int getDisasterReadinessIndex() {
        return disasterReadinessIndex;
    }

    public void setDisasterReadinessIndex(int disasterReadinessIndex) {
        this.disasterReadinessIndex = disasterReadinessIndex;
    }
}
