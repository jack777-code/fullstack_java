package com.disasterrelief.hub.presentation.dto.response;

import com.disasterrelief.hub.database.entity.IncidentEntity;
import com.disasterrelief.hub.database.entity.enums.DisasterType;
import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.database.entity.enums.SeverityLevel;
import java.time.LocalDateTime;

public class IncidentResponse {

    private Long id;
    private String incidentCode;
    private String title;
    private DisasterType disasterType;
    private SeverityLevel severity;
    private IncidentStatus status;
    private Integer affectedPopulation;
    private String locationName;
    private Double latitude;
    private Double longitude;
    private String description;
    private String reportedBy;
    private String contactPhone;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public IncidentResponse() {
    }

    public static IncidentResponse fromEntity(IncidentEntity entity) {
        if (entity == null) return null;
        IncidentResponse dto = new IncidentResponse();
        dto.setId(entity.getId());
        dto.setIncidentCode(entity.getIncidentCode());
        dto.setTitle(entity.getTitle());
        dto.setDisasterType(entity.getDisasterType());
        dto.setSeverity(entity.getSeverity());
        dto.setStatus(entity.getStatus());
        dto.setAffectedPopulation(entity.getAffectedPopulation());
        dto.setLocationName(entity.getLocationName());
        dto.setLatitude(entity.getLatitude());
        dto.setLongitude(entity.getLongitude());
        dto.setDescription(entity.getDescription());
        dto.setReportedBy(entity.getReportedBy());
        dto.setContactPhone(entity.getContactPhone());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        return dto;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIncidentCode() {
        return incidentCode;
    }

    public void setIncidentCode(String incidentCode) {
        this.incidentCode = incidentCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public DisasterType getDisasterType() {
        return disasterType;
    }

    public void setDisasterType(DisasterType disasterType) {
        this.disasterType = disasterType;
    }

    public SeverityLevel getSeverity() {
        return severity;
    }

    public void setSeverity(SeverityLevel severity) {
        this.severity = severity;
    }

    public IncidentStatus getStatus() {
        return status;
    }

    public void setStatus(IncidentStatus status) {
        this.status = status;
    }

    public Integer getAffectedPopulation() {
        return affectedPopulation;
    }

    public void setAffectedPopulation(Integer affectedPopulation) {
        this.affectedPopulation = affectedPopulation;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReportedBy() {
        return reportedBy;
    }

    public void setReportedBy(String reportedBy) {
        this.reportedBy = reportedBy;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
