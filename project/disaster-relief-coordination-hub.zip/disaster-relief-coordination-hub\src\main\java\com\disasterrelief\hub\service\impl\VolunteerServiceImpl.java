package com.disasterrelief.hub.service.impl;

import com.disasterrelief.hub.database.entity.AuditLogEntity;
import com.disasterrelief.hub.database.entity.VolunteerEntity;
import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;
import com.disasterrelief.hub.presentation.dto.request.VolunteerRegisterRequest;
import com.disasterrelief.hub.presentation.dto.response.VolunteerResponse;
import com.disasterrelief.hub.presentation.exception.ResourceNotFoundException;
import com.disasterrelief.hub.repository.AuditLogRepository;
import com.disasterrelief.hub.repository.IncidentRepository;
import com.disasterrelief.hub.repository.VolunteerRepository;
import com.disasterrelief.hub.service.NotificationService;
import com.disasterrelief.hub.service.VolunteerService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class VolunteerServiceImpl implements VolunteerService {

    private final VolunteerRepository volunteerRepository;
    private final IncidentRepository incidentRepository;
    private final AuditLogRepository auditLogRepository;
    private final NotificationService notificationService;

    public VolunteerServiceImpl(VolunteerRepository volunteerRepository,
                                IncidentRepository incidentRepository,
                                AuditLogRepository auditLogRepository,
                                NotificationService notificationService) {
        this.volunteerRepository = volunteerRepository;
        this.incidentRepository = incidentRepository;
        this.auditLogRepository = auditLogRepository;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional(readOnly = true)
    public List<VolunteerResponse> getAllVolunteers() {
        return volunteerRepository.findAll().stream()
                .map(VolunteerResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<VolunteerResponse> getAvailableVolunteers() {
        return volunteerRepository.findByIsAvailableTrue().stream()
                .map(VolunteerResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<VolunteerResponse> getAvailableBySkill(VolunteerSkill skill) {
        return volunteerRepository.findByPrimarySkillAndIsAvailableTrue(skill).stream()
                .map(VolunteerResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public VolunteerResponse registerVolunteer(VolunteerRegisterRequest request) {
        String code = "VOL-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        VolunteerEntity entity = new VolunteerEntity(
                code,
                request.getFullName(),
                request.getEmail(),
                request.getPhone(),
                request.getPrimarySkill(),
                true,
                null,
                request.getCurrentLocation() != null ? request.getCurrentLocation() : "General Standby"
        );

        VolunteerEntity saved = volunteerRepository.save(entity);

        auditLogRepository.save(new AuditLogEntity(
                "VOLUNTEER_REGISTERED",
                "Volunteer",
                saved.getVolunteerCode(),
                "Registered: " + saved.getFullName() + " [" + saved.getPrimarySkill() + "]",
                "VOLUNTEER_PORTAL"
        ));

        notificationService.notifyMetricsChanged();
        return VolunteerResponse.fromEntity(saved);
    }

    @Override
    public VolunteerResponse assignToIncident(Long volunteerId, Long incidentId) {
        VolunteerEntity volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException("Volunteer not found with ID: " + volunteerId));

        if (!incidentRepository.existsById(incidentId)) {
            throw new ResourceNotFoundException("Incident not found with ID: " + incidentId);
        }

        volunteer.setIsAvailable(false);
        volunteer.setCurrentAssignedIncidentId(incidentId);
        VolunteerEntity updated = volunteerRepository.save(volunteer);

        auditLogRepository.save(new AuditLogEntity(
                "VOLUNTEER_DEPLOYED",
                "Volunteer",
                volunteer.getVolunteerCode(),
                "Deployed to Incident #" + incidentId,
                "TACTICAL_COORDINATOR"
        ));

        notificationService.notifyMetricsChanged();
        return VolunteerResponse.fromEntity(updated);
    }

    @Override
    public VolunteerResponse releaseVolunteer(Long volunteerId) {
        VolunteerEntity volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException("Volunteer not found with ID: " + volunteerId));

        volunteer.setIsAvailable(true);
        volunteer.setCurrentAssignedIncidentId(null);
        VolunteerEntity updated = volunteerRepository.save(volunteer);

        auditLogRepository.save(new AuditLogEntity(
                "VOLUNTEER_STANDBY",
                "Volunteer",
                volunteer.getVolunteerCode(),
                "Released back to standby pool",
                "TACTICAL_COORDINATOR"
        ));

        notificationService.notifyMetricsChanged();
        return VolunteerResponse.fromEntity(updated);
    }
}
