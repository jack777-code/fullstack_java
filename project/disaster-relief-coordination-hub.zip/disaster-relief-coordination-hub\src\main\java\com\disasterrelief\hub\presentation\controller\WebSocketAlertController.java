package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.presentation.websocket.EmergencyAlertMessage;
import com.disasterrelief.hub.service.NotificationService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

@Controller
public class WebSocketAlertController {

    private final NotificationService notificationService;

    public WebSocketAlertController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @MessageMapping("/broadcast-alert")
    @SendTo("/topic/alerts")
    public EmergencyAlertMessage broadcastEmergency(@Payload EmergencyAlertMessage alert) {
        alert.setTimestamp(LocalDateTime.now());
        return alert;
    }

    @MessageMapping("/ping")
    @SendTo("/topic/ping")
    public String ping() {
        return "PONG_" + System.currentTimeMillis();
    }
}
