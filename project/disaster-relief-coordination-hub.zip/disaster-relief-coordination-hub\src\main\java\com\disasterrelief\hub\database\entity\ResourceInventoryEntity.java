package com.disasterrelief.hub.database.entity;

import com.disasterrelief.hub.database.entity.enums.ResourceCategory;
import jakarta.persistence.*;

@Entity
@Table(name = "resource_inventory")
public class ResourceInventoryEntity extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "resource_code", nullable = false, unique = true, length = 32)
    private String resourceCode;

    @Column(name = "name", nullable = false, length = 120)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false, length = 30)
    private ResourceCategory category;

    @Column(name = "unit", nullable = false, length = 30)
    private String unit;

    @Column(name = "total_quantity", nullable = false)
    private Integer totalQuantity;

    @Column(name = "allocated_quantity", nullable = false)
    private Integer allocatedQuantity;

    @Column(name = "available_quantity", nullable = false)
    private Integer availableQuantity;

    @Column(name = "warehouse_location", nullable = false, length = 150)
    private String warehouseLocation;

    @Column(name = "minimum_threshold", nullable = false)
    private Integer minimumThreshold;

    public ResourceInventoryEntity() {
    }

    public ResourceInventoryEntity(String resourceCode, String name, ResourceCategory category, String unit,
                                   Integer totalQuantity, Integer allocatedQuantity, Integer availableQuantity,
                                   String warehouseLocation, Integer minimumThreshold) {
        this.resourceCode = resourceCode;
        this.name = name;
        this.category = category;
        this.unit = unit;
        this.totalQuantity = totalQuantity;
        this.allocatedQuantity = allocatedQuantity;
        this.availableQuantity = availableQuantity;
        this.warehouseLocation = warehouseLocation;
        this.minimumThreshold = minimumThreshold;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ResourceCategory getCategory() {
        return category;
    }

    public void setCategory(ResourceCategory category) {
        this.category = category;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public Integer getAllocatedQuantity() {
        return allocatedQuantity;
    }

    public void setAllocatedQuantity(Integer allocatedQuantity) {
        this.allocatedQuantity = allocatedQuantity;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public String getWarehouseLocation() {
        return warehouseLocation;
    }

    public void setWarehouseLocation(String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    public Integer getMinimumThreshold() {
        return minimumThreshold;
    }

    public void setMinimumThreshold(Integer minimumThreshold) {
        this.minimumThreshold = minimumThreshold;
    }
}
