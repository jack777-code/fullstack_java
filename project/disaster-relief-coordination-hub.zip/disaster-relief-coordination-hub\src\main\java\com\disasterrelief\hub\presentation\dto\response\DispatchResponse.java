package com.disasterrelief.hub.presentation.dto.response;

import com.disasterrelief.hub.database.entity.DispatchAllocationEntity;
import java.time.LocalDateTime;

public class DispatchResponse {

    private Long id;
    private String allocationCode;
    private Long incidentId;
    private String incidentTitle;
    private Long resourceId;
    private String resourceName;
    private Integer quantityDispatched;
    private String unit;
    private String dispatchStatus;
    private LocalDateTime dispatchedAt;
    private String dispatchedBy;
    private String notes;

    public DispatchResponse() {
    }

    public static DispatchResponse fromEntity(DispatchAllocationEntity entity) {
        if (entity == null) return null;
        DispatchResponse dto = new DispatchResponse();
        dto.setId(entity.getId());
        dto.setAllocationCode(entity.getAllocationCode());
        if (entity.getIncident() != null) {
            dto.setIncidentId(entity.getIncident().getId());
            dto.setIncidentTitle(entity.getIncident().getTitle());
        }
        if (entity.getResource() != null) {
            dto.setResourceId(entity.getResource().getId());
            dto.setResourceName(entity.getResource().getName());
            dto.setUnit(entity.getResource().getUnit());
        }
        dto.setQuantityDispatched(entity.getQuantityDispatched());
        dto.setDispatchStatus(entity.getDispatchStatus());
        dto.setDispatchedAt(entity.getDispatchedAt());
        dto.setDispatchedBy(entity.getDispatchedBy());
        dto.setNotes(entity.getNotes());
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAllocationCode() {
        return allocationCode;
    }

    public void setAllocationCode(String allocationCode) {
        this.allocationCode = allocationCode;
    }

    public Long getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(Long incidentId) {
        this.incidentId = incidentId;
    }

    public String getIncidentTitle() {
        return incidentTitle;
    }

    public void setIncidentTitle(String incidentTitle) {
        this.incidentTitle = incidentTitle;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public Integer getQuantityDispatched() {
        return quantityDispatched;
    }

    public void setQuantityDispatched(Integer quantityDispatched) {
        this.quantityDispatched = quantityDispatched;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDispatchStatus() {
        return dispatchStatus;
    }

    public void setDispatchStatus(String dispatchStatus) {
        this.dispatchStatus = dispatchStatus;
    }

    public LocalDateTime getDispatchedAt() {
        return dispatchedAt;
    }

    public void setDispatchedAt(LocalDateTime dispatchedAt) {
        this.dispatchedAt = dispatchedAt;
    }

    public String getDispatchedBy() {
        return dispatchedBy;
    }

    public void setDispatchedBy(String dispatchedBy) {
        this.dispatchedBy = dispatchedBy;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
