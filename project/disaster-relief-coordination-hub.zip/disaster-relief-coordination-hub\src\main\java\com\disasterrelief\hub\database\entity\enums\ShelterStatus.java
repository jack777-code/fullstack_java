package com.disasterrelief.hub.database.entity.enums;

public enum ShelterStatus {
    OPEN,
    NEAR_CAPACITY,
    FULL,
    EVACUATING,
    CLOSED
}
