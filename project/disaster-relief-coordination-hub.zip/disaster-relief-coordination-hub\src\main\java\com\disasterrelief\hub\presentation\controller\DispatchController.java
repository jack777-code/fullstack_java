package com.disasterrelief.hub.presentation.controller;

import com.disasterrelief.hub.presentation.dto.request.ResourceAllocationRequest;
import com.disasterrelief.hub.presentation.dto.response.ApiResponse;
import com.disasterrelief.hub.presentation.dto.response.DispatchResponse;
import com.disasterrelief.hub.service.DispatchService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dispatches")
@CrossOrigin(origins = "*")
public class DispatchController {

    private final DispatchService dispatchService;

    public DispatchController(DispatchService dispatchService) {
        this.dispatchService = dispatchService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<DispatchResponse>> dispatchResource(@Valid @RequestBody ResourceAllocationRequest request) {
        DispatchResponse response = dispatchService.dispatchResource(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Resource dispatch logged and en route", response));
    }

    @GetMapping("/incident/{incidentId}")
    public ResponseEntity<ApiResponse<List<DispatchResponse>>> getByIncident(@PathVariable Long incidentId) {
        return ResponseEntity.ok(ApiResponse.success(dispatchService.getDispatchesForIncident(incidentId)));
    }

    @GetMapping("/recent")
    public ResponseEntity<ApiResponse<List<DispatchResponse>>> getRecentDispatches() {
        return ResponseEntity.ok(ApiResponse.success(dispatchService.getRecentDispatches()));
    }
}
