package com.disasterrelief.hub.database.entity;

import com.disasterrelief.hub.database.entity.enums.DisasterType;
import com.disasterrelief.hub.database.entity.enums.IncidentStatus;
import com.disasterrelief.hub.database.entity.enums.SeverityLevel;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "incidents")
public class IncidentEntity extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_code", nullable = false, unique = true, length = 32)
    private String incidentCode;

    @Column(name = "title", nullable = false, length = 150)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "disaster_type", nullable = false, length = 30)
    private DisasterType disasterType;

    @Enumerated(EnumType.STRING)
    @Column(name = "severity", nullable = false, length = 20)
    private SeverityLevel severity;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private IncidentStatus status;

    @Column(name = "affected_population")
    private Integer affectedPopulation;

    @Column(name = "location_name", nullable = false, length = 150)
    private String locationName;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "description", length = 2000)
    private String description;

    @Column(name = "reported_by", length = 100)
    private String reportedBy;

    @Column(name = "contact_phone", length = 30)
    private String contactPhone;

    @OneToMany(mappedBy = "incident", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<DispatchAllocationEntity> allocations = new ArrayList<>();

    public IncidentEntity() {
    }

    public IncidentEntity(String incidentCode, String title, DisasterType disasterType, SeverityLevel severity,
                          IncidentStatus status, Integer affectedPopulation, String locationName,
                          Double latitude, Double longitude, String description,
                          String reportedBy, String contactPhone) {
        this.incidentCode = incidentCode;
        this.title = title;
        this.disasterType = disasterType;
        this.severity = severity;
        this.status = status;
        this.affectedPopulation = affectedPopulation;
        this.locationName = locationName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.description = description;
        this.reportedBy = reportedBy;
        this.contactPhone = contactPhone;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIncidentCode() {
        return incidentCode;
    }

    public void setIncidentCode(String incidentCode) {
        this.incidentCode = incidentCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public DisasterType getDisasterType() {
        return disasterType;
    }

    public void setDisasterType(DisasterType disasterType) {
        this.disasterType = disasterType;
    }

    public SeverityLevel getSeverity() {
        return severity;
    }

    public void setSeverity(SeverityLevel severity) {
        this.severity = severity;
    }

    public IncidentStatus getStatus() {
        return status;
    }

    public void setStatus(IncidentStatus status) {
        this.status = status;
    }

    public Integer getAffectedPopulation() {
        return affectedPopulation;
    }

    public void setAffectedPopulation(Integer affectedPopulation) {
        this.affectedPopulation = affectedPopulation;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReportedBy() {
        return reportedBy;
    }

    public void setReportedBy(String reportedBy) {
        this.reportedBy = reportedBy;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public List<DispatchAllocationEntity> getAllocations() {
        return allocations;
    }

    public void setAllocations(List<DispatchAllocationEntity> allocations) {
        this.allocations = allocations;
    }
}
