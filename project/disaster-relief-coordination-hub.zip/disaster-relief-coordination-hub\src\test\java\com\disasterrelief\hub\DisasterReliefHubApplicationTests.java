package com.disasterrelief.hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisasterReliefHubApplicationTests {

    @Test
    void contextLoads() {
    }

}
