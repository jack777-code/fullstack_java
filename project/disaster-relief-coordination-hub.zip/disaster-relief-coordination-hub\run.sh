#!/usr/bin/env bash
# =========================================================================
#       DISASTER RELIEF COORDINATION HUB - UNIX STARTUP LAUNCHER
# =========================================================================

echo "========================================================================="
echo "      DISASTER RELIEF COORDINATION HUB - STARTUP LAUNCHER"
echo "========================================================================="
echo ""

if ! command -v java &> /dev/null; then
    echo "[ERROR] Java 17+ is not detected in your PATH."
    echo "Please install Java 17 or higher (e.g. from https://adoptium.net)."
    echo ""
    echo "QUICK PREVIEW OPTION:"
    echo "You can open 'src/main/resources/static/index.html' in your browser to view the UI."
    exit 1
fi

echo "[OK] Java environment detected."
echo "Starting Spring Boot application on port 8080..."
echo "Web Portal:  http://localhost:8080"
echo "H2 Database: http://localhost:8080/h2-console"
echo ""

chmod +x mvnw
./mvnw spring-boot:run
