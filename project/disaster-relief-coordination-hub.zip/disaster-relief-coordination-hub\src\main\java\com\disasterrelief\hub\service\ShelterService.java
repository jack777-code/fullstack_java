package com.disasterrelief.hub.service;

import com.disasterrelief.hub.database.entity.enums.ShelterStatus;
import com.disasterrelief.hub.presentation.dto.request.ShelterCheckInRequest;
import com.disasterrelief.hub.presentation.dto.response.ShelterResponse;

import java.util.List;

public interface ShelterService {
    List<ShelterResponse> getAllShelters();
    List<ShelterResponse> getAvailableShelters();
    ShelterResponse getShelterById(Long id);
    ShelterResponse checkInEvacuees(ShelterCheckInRequest request);
    ShelterResponse updateShelterStatus(Long id, ShelterStatus status);
}
