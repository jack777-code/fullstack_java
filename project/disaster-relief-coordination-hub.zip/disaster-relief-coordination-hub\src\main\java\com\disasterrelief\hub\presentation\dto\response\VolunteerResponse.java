package com.disasterrelief.hub.presentation.dto.response;

import com.disasterrelief.hub.database.entity.VolunteerEntity;
import com.disasterrelief.hub.database.entity.enums.VolunteerSkill;

public class VolunteerResponse {

    private Long id;
    private String volunteerCode;
    private String fullName;
    private String email;
    private String phone;
    private VolunteerSkill primarySkill;
    private Boolean isAvailable;
    private Long currentAssignedIncidentId;
    private String currentLocation;

    public VolunteerResponse() {
    }

    public static VolunteerResponse fromEntity(VolunteerEntity entity) {
        if (entity == null) return null;
        VolunteerResponse dto = new VolunteerResponse();
        dto.setId(entity.getId());
        dto.setVolunteerCode(entity.getVolunteerCode());
        dto.setFullName(entity.getFullName());
        dto.setEmail(entity.getEmail());
        dto.setPhone(entity.getPhone());
        dto.setPrimarySkill(entity.getPrimarySkill());
        dto.setIsAvailable(entity.getIsAvailable());
        dto.setCurrentAssignedIncidentId(entity.getCurrentAssignedIncidentId());
        dto.setCurrentLocation(entity.getCurrentLocation());
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVolunteerCode() {
        return volunteerCode;
    }

    public void setVolunteerCode(String volunteerCode) {
        this.volunteerCode = volunteerCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public VolunteerSkill getPrimarySkill() {
        return primarySkill;
    }

    public void setPrimarySkill(VolunteerSkill primarySkill) {
        this.primarySkill = primarySkill;
    }

    public Boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(Boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Long getCurrentAssignedIncidentId() {
        return currentAssignedIncidentId;
    }

    public void setCurrentAssignedIncidentId(Long currentAssignedIncidentId) {
        this.currentAssignedIncidentId = currentAssignedIncidentId;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }
}
